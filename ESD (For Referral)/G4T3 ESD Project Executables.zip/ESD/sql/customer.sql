-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 14, 2019 at 06:42 AM
-- Server version: 5.7.19
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `customer`
--
CREATE DATABASE IF NOT EXISTS `customer` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `customer`;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE IF NOT EXISTS `customer` (
  `userID` VARCHAR(128),
  `name` VARCHAR(128) NOT NULL,
  `gender` VARCHAR(6) NOT NULL,
  `health_records` VARCHAR(128) NOT NULL,
  `approved_drugs` VARCHAR(128) NOT NULL,
  `address` VARCHAR(128) NOT NULL,
  `email` VARCHAR(128) NOT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`userID`, `name`, `gender`, `health_records`, `approved_drugs` , `address`, `email`) VALUES
('Looi.James', 'Looi James', 'Male', 'Dwarfism', 'General', '120 Tanjong Rhu Road', 'looijames1997@gmail.com'),
('Chua.Shao.Shxuan', 'Chua Shao Shxuan', 'Male', 'Asthma, High Blood Pressure, High Cholesterol', 'General, Cholesterol, High_Blood_Pressure, Asthma', '1 Joo Koon Cir', 'shaoshxuan.chua@gmail.com'),
('Sheldon.Low', 'Sheldon Low', 'Male', 'Pollen Allergy', 'General, Allergy', '1 Punggol Field Walk', 'shoyrant@gmail.com'),
('John.Doe', 'John Doe', 'Male', 'McNugget Allergy', 'General, Cholesterol, High_Blood_Pressure, Asthma', '149 Woodlands Street 13', 'ESDg4t3tester1@gmail.com')
;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
