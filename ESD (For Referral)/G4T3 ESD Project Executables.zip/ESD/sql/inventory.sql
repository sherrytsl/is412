-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 16, 2019 at 01:55 AM
-- Server version: 5.7.19
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory`
--
CREATE DATABASE IF NOT EXISTS `inventory` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `inventory`;

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
CREATE TABLE IF NOT EXISTS `inventory` (
  `drugID` INT(10) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(128) NOT NULL,
  `drug_description` VARCHAR(128) NOT NULL,
  `drug_type` VARCHAR(128) NOT NULL,
  `quantity` INT(10) NOT NULL,
  `price` FLOAT(4,2) NOT NULL,
  PRIMARY KEY (`drugID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`drugID`, `name`, `drug_description`, `drug_type`, `quantity`, `price`) VALUES
(1, 'Paracetamol', 'A pain reliever and a fever reducer', 'General', '100', '2.50'),
(2, 'Gaviscon', 'Treats hearburn, upset stomach or indigestion', 'General', '100', '3.50'),
(3, 'Leukotriene Modifiers', 'Prevent asthma by blocking the action of leukotrienes', 'Asthma', '100', '20.50'),
(4, 'Atorvastatin', 'Used to treat high cholesterol', 'Cholesterol', '100', '49.00'),
(5, 'Diuretics', 'Treats high blood pressure', 'High_Blood_Pressure', '100', '32.00'),
(6, 'Loratadine', 'Antihistamine that treats symptoms such as pollen allergy', 'Allergy', '100', '11.90')
;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
