-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 14, 2019 at 06:42 AM
-- Server version: 5.7.19
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pharmacist`
--
CREATE DATABASE IF NOT EXISTS `pharmacist` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `pharmacist`;

-- --------------------------------------------------------

--
-- Table structure for table `pharmacist`
--

DROP TABLE IF EXISTS `pharmacist`;
CREATE TABLE IF NOT EXISTS `pharmacist` (
  `orderID` int(20) NOT NULL,
  `userID` varchar(128) NOT NULL,
  `name` varchar(128) NOT NULL,
  `status` varchar(128) NOT NULL,
  `remarks` varchar(128) NOT NULL,
  `email` VARCHAR(128) NOT NULL,
  PRIMARY KEY (`orderID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pharmacist`
--



INSERT INTO `pharmacist` (`orderID`, `userID`, `name`, `status`, `remarks`, `email`) VALUES
(970898, 'Charis.Koh', 'Charis Koh', 'Approved', 'NIL', 'ckoh9925@gmail.com'),
(959683, 'Autumn.Teo', 'Autumn Teo', 'Approved', 'Will need to monitor and follow-up', 'autumnteo96@gmail.com'),
(970899, 'James.Looi', 'James Looi', 'Not Approved', 'NIL', 'james.looi.2018@smu.edu.sg')
;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;


