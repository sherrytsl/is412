--
-- Database: `booking`
--
CREATE DATABASE IF NOT EXISTS `booking` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `booking`;


SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

DROP TABLE IF EXISTS `booking`;
CREATE TABLE IF NOT EXISTS `booking` (
	`orderid` int(11) not null, 
    `userid` varchar(50) not null,
    `drugsOrdered` varchar(100) not null, 
    `drugQuantity` int(11) not null, 
    `status` varchar(100) not null,
    `timeslot` datetime NOT NULL,
    `cost` float NOT NULL,
    `address` varchar(50) NOT NULL,
    PRIMARY KEY (`orderid`, `drugsOrdered`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `booking`
--

COMMIT;
