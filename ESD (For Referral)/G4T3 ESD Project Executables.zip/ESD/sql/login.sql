-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 14, 2019 at 06:42 AM
-- Server version: 5.7.19
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pharmacist`
--
CREATE DATABASE IF NOT EXISTS `login` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `login`;

-- --------------------------------------------------------

--
-- Table structure for table `pharmacist`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE IF NOT EXISTS `login` (
  `email` varchar(123) NOT NULL,
  `usertype` varchar(128) NOT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pharmacist`
--


INSERT INTO `login` (`email`, `usertype`) VALUES
('ckoh9925@gmail.com', 'pharmacist'),
('autumnteo96@gmail.com', 'pharmacist'),
('looijames1997@gmail.com', 'customer'),
('shaoshxuan.chua@gmail.com', 'customer'),
('shoyrant@gmail.com', 'customer'),
('chiang.m.591@gmail.com', 'deliveryman'),
('tom.jerry@gmail.com', 'deliveryman'),
('james.looi.2018@smu.edu.sg', 'pharmacist'),
('shutterbugger27@gmail.com', 'deliveryman'),
('sheldon.low.2018@smu.edu.sg', 'pharmacist'),
('shoyrant@hotmail.com', 'deliveryman'),
('chickenricepowerup@gmail.com', 'deliveryman'),
('ESDg4t3tester1@gmail.com', 'customer'),
('ESDg4t3tester2@gmail.com', 'pharmacist'),
('ESDg4t3tester3@gmail.com', 'deliveryman')

;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;


