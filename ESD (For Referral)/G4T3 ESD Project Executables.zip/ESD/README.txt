# ESD
Hello there and welcome to Dr.Who

Please follow the instructions below IN ORDER so as to launch all the required docker image/containers and auxillery services

1) Load up all SQL files for database creation
2) Create docker images/container for each folder in "app/backend" directory EXCEPT for tele_bot and kong folders
3) When launching docker containers on Docker Desktop, MAKE VERY SURE to turn on login container FIRST followed by rabbit-mq container. 
This is so that the correct internal IP Address will be assigned to rabbit-mq so that all subsequent microservice containers will connect to the rabbit-mq container to enable AMQP communications between each of them
4) If containers fail to connect with rabbitmq container, double check internal IP address of that container and ensure all other microservices have the correct localhost assignment (equal to the rabbitmq internal ip)
5) Edit the telegram_bot py file in tele_bot directory, line 49 to reflect the IPv4 of the computer hosting/testing the service

TEST Accounts to use: (MUST use google log in)

Customer account:
email: ESDg4t3tester1@gmail.com
password: ESDg4t3tester1password

Pharmacist account:
email: ESDg4t3tester2@gmail.com
password: ESDg4t3tester1password

Delivery Man account:
email: ESDg4t3tester3@gmail.com
password: ESDg4t3tester1password

PAYPAL payment details:

Sandbox Personal Account Details (USE THIS FOR PAYMENT testing)
First Name: John
Last Name: Doe
Email ID: sb-rfxnn1280901@personal.example.com
System Generated Password: 8f"=oTqt

Sandbox Business Account Details (this is the receiving account)
First Name: John
Last Name: Doe
Email ID: sb-ttbmq1240644@business.example.com
System Generated Password: t80(KR5_


Telebot instructions:
Bot ID: @esdchecking_bot
/start to activate (assuming its alr hosted on local computer)