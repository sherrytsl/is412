<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="gmaps.css">
    <title>Google Maps</title>
</head>
<body>
    <div class="h_iframe">
        <script>
            var destination_address = sessionStorage.getItem("mapsAddress");
            sessionStorage.removeItem("mapsAddress");
            destination_address.replace(/\s/g, '+');
            console.log(destination_address);
            console.log(destination_address.replace(/\s/g, '+'));

            document.write("<iframe frameborder='1' style='border:1' src='https://www.google.com/maps/embed/v1/directions?key=AIzaSyBEdfeknj-CxXUVROr_uKrxPgkJzMnA0Wc&origin=Raffles+Place&destination="+destination_address+"&avoid=tolls|highways' allowfullscreen></iframe>");
        </script>
    </div>
</body>
</html>


