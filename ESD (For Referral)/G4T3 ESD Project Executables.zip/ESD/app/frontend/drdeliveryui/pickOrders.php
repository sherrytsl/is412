<?php
    session_start();
    if (empty($_SESSION)){
        header("Location: ../login-logout/index.php");
        exit();
    } 
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/stylesheet.css">
    <link rel="stylesheet" type="text/css" href="../css/stylesheet.css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400&display=swap" rel="stylesheet">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>

    <title>Dr Delivery UI</title>
</head>
<body>

    <header>
        <h1 class="logo">Dr. Delivery UI</h1>
        <nav>
            <ul class="nav_links">
                <li><a href="deliveryindex.php">My Profile</a></li>
                <li><a href="pickOrders.php" class="current">Pick Deliveries</a></li>
                <li><a href="toBeDelivered.php">To Be Delivered</a></li>
            </ul>
        </nav>
        <a href="../login-logout/logout.php"><button>Logout</button></a>
    </header>

    <div class="orders" style="text-align:center; padding: 50px">
        <table style="text-align:center; margin:auto; padding:30px" id="pickOrders">
            <tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Timeslot Requested</th>
                <th>Location</th>
                <th>Pick This Delivery</th>
            </tr>
            <tbody>
            </tbody>
        </table>
    </div>
    <script>
        async function funcs(){

            var serviceURL = "http://127.0.0.1:5008/booking/delivery";

            try {
                const response = 
                    await fetch(
                        serviceURL, {
                            method: 'GET',
                    });
            } catch (error){

            }

            var serviceURL = "http://127.0.0.1:5006/all";

            try {
                const response = 
                    await fetch(
                        serviceURL, {
                            method: 'GET',
                    });
                
                const data = await response.json();

                ordersToPick = data.all;

                pickOrdersRows = "";

                for (var i=0; i<ordersToPick.length; i++){
                    if (ordersToPick[i].status == "Available"){
                        var orderid = ordersToPick[i].orderid;
                        var customer = ordersToPick[i].customerName;
                        var timeslot = ordersToPick[i].timeslot;
                        var address = ordersToPick[i].address;

                        pickOrdersRows += "<tr id='" + orderid + "'><td>" + orderid + "</td><td>" + customer + "</td><td>" + timeslot + "</td><td>" + address + "</td><td><button onclick=\"pickUpOrder('" + orderid + "')\">PickUp</button></td></tr>"
                    }
                }
                $('#pickOrders').append(pickOrdersRows);

            } catch (error){
                console.log(error);
            }
        }

        window.onload = funcs;

        async function pickUpOrder(orderid){

            var toSend = {"email": '<?php echo $_SESSION['email']?>'};

            var serviceURL = "http://127.0.0.1:5006/deliveryman/" + orderid;

            try {
                const response =
                    await fetch(
                        serviceURL, {
                            method: 'POST',
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify(toSend),
                    });

                const data = await response.json();
                console.log(data);
                if (response.ok){
                    console.log("ok");
                    $('#'+orderid).hide();
                }
            } catch (error){
                console.log("fail");
            };
        }
    </script>
</body>
</head>