<?php
    session_start();
    if (!isset($_SESSION)){
        header("Location: ../login-logout/index.php");
        exit();
    }

    if (isset($_COOKIE["cart"])){
        $cart = json_decode($_COOKIE["cart"], true);
        foreach ($cart as $key => $value){
            if (isset($_SESSION["cart"])){
                if (array_key_exists($key, $_SESSION["cart"])){
                    if ($_SESSION["cart"][$key]['qty'] + $value['qty'] <= $value['stock']){
                        $_SESSION["cart"][$key]['qty'] += $value['qty'];
                        $_SESSION["cart"][$key]['cost'] += $value['qty']*$value['cost'];
                    } else {
                        $_SESSION["cart"][$key]['qty'] = $value['stock'];
                        $_SESSION["cart"][$key]['cost'] = $value['stock']*$value['cost'];
                        echo "<script type='text/javascript'>alert('You have maxed out quantity for $key');</script>";
                    }
                } else {
                    $_SESSION["cart"][$key]['qty'] = $value['qty'];
                    $_SESSION["cart"][$key]['cost'] = $value['qty']*$value['cost'];
                    $_SESSION["cart"][$key]["address"] = $value["address"];
                }
            } else {
                $_SESSION["cart"][$key]['qty'] = $value['qty'];
                $_SESSION["cart"][$key]['cost'] = $value['cost']*$value["qty"];
                $_SESSION["cart"][$key]["address"] = $value["address"];
            }
        }
        setcookie("cart", "", time() - 3600);
    }
    
    if (isset($_POST)){
        foreach ($_POST as $key => $value){
            if (isset($_SESSION["cart"][$key])){
                $_SESSION["cart"]["totalCost"] -= $_SESSION["cart"][$key]['cost'];
                unset($_SESSION["cart"][$key]);
            }
        }
    }

    if (isset($_SESSION["checkoutError"])){
        echo $_SESSION["checkoutError"];
        unset($_SESSION["checkoutError"]);
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../../css/stylesheet.css">
    <link rel="stylesheet" type="text/css" href="../css/stylesheet.css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400&display=swap" rel="stylesheet">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>

    <title>Dr Who UI</title>
</head>
<body>
    <header>
        <h1 class="logo">Dr. WHO UI</h1>
        <nav>
            <ul class="nav_links">
                <li><a href="../whoindex.php">My Profile</a></li>
                <li><a href="drwhoorder.php">Place an Order</a></li>
                <li><a href="../drwhopending.php">Pending/ Completed Order</a></li>
                <li><a href="cart.php" class="current">Your Cart</a></li>
            </ul>
        </nav>
        <a class="cta" href="../../login-logout/logout.php"><button>Logout</button></a>
    </header>

    <div class="cart">
        <h3 style="color: #36d39f">Your Cart</h3>
        <table style="text-align:center; margin-left:auto; margin-right:auto; padding-top:'50px'">
            <tr>
                <th>Drug Name</th>
                <th>Quantity</th>
                <th>Delete item</th>
            </tr>
            <?php
                if (isset($_SESSION["cart"])){
                    $_SESSION["cart"]["totalCost"] = 0;
                    foreach ($_SESSION["cart"] as $item => $qty){
                        if ($item != "totalCost"){
                            $_SESSION["cart"]["totalCost"] += $qty['cost'];
                            $replaced = str_replace('-', ' ', $item);
                            $qty1 = $qty['qty'];
                            echo "<tr>
                                    <td>{$replaced}</td>
                                    <td>{$qty1}</td>
                                    <td style='padding-top:10px;'>
                                        <form action='#' method='POST'>
                                            <input type='submit' value='Delete' name='{$item}'/>
                                        </form>
                                    </td>
                                </tr>";
                        }
                    }
                }

                if (isset($_SESSION["cart"]["totalCost"])){
                    $totalCost = $_SESSION['cart']["totalCost"];
                } else {
                    $totalCost = 0;
                }
                
                echo "<tr>
                        <td colspan='3'>Total Cost: $ {$totalCost}</td>
                    </tr>";
            ?>
        </table>
    </div>

    <div class="datetime">
        <h3 style="color: #36d39f">Pick Date and Time for Delivery</h3>
        <table style="text-align:center; margin-left:auto; margin-right:auto; padding-top:'50px';">
            <tr>
                <th>Date</th>
                <th>Time</th>
            </tr>
            <form method="POST" action="checkout.php">
            <tr>
                <td>
                    <select name="date" id="date" onChange="changecat(this.value);" required>
                        <option value="" disabled selected>Select</option>
                    </select>
                </td>
                <td>
                    <select name="time" id="time" required>
                        <option value="" disabled selected>Select</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td colspan="2"><button type="submit" value="checkout" name="checkout">Check Out</button><td>
            </tr>
            </form>
        </table>    
    </div>

    <script>
        var dates_time = {};
        async function funcs(){
            // var email = '<?php echo $_SESSION["email"]?>';
            var serviceURL1 = "http://127.0.0.1:5003/schedule";

            try {
                const response =
                    await fetch(
                        serviceURL1, {
                            method: 'GET',
                    });

                const data1 = await response.json();
                var datetime = data1["available timeslots"];

                dates_time = {};
                
                for (var i=0; i<datetime.length; i++){
                    if (datetime[i]["status"] == "available"){
                        splitData = datetime[i]["date time"].split(" ");
                        var date = splitData.slice(0, 4).join(" ");
                        var time = splitData.slice(4, splitData.length-1).join(" ");
                        if (!(date in dates_time)){
                            dates_time[date] = [time];
                        } else {
                            dates_time[date].push(time);
                        }
                    }
                }

                var dateOptions = "<option value='' disabled selected>Select</option>";
                for (date in dates_time) {
                    dateOptions += "<option>" + date + "</option>";
                }
                document.getElementById("date").innerHTML = dateOptions;
                
            } catch (error){

            }
        }
        window.onload = funcs;


        function changecat(value) {
            if (value.length == 0){
                document.getElementById("time").innerHTML = "<option></option>";
            } else {
                var timeOptions = "";
                for (var i=0; i<dates_time[value].length; i++){
                    timeOptions += "<option>" + dates_time[value][i] + "</option>";
                }
                document.getElementById("time").innerHTML = timeOptions;
            }
        }
    </script>
</body>
</html>