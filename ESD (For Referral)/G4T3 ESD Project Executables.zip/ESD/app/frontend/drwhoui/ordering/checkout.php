<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../../css/stylesheet.css">
    <link rel="stylesheet" type="text/css" href="../css/stylesheet.css">
    <title>Paypal Checkout</title>
</head>
<body>

    <?php
        session_start();
        if (!isset($_POST["checkout"])){
            header("Location: cart.php");
            exit();
        } elseif (!isset($_SESSION["cart"]) or empty($_SESSION["cart"])){
            $_SESSION["checkoutError"] = "<script>alert('Cart is empty!')</script>";
            header("Location: cart.php");
            exit();
        }

        $userid = $_SESSION["userid"];


        $orders = [];
        $datetime = "";
        if (isset($_POST["time"]) and isset($_POST["date"])){
            $date = str_replace(" ", "-", substr($_POST["date"], 5, 24));
            $datetime1 = date_create("{$date} {$_POST['time']}", timezone_open("Asia/Singapore"));
            $datetime = date_format($datetime1,"Y/m/d H:i:s");
        }

        
        foreach ($_SESSION["cart"] as $item => $value){
            if ($item != "totalCost"){
                $itemJSON = array("drug"=>$item, "quantity"=>$value['qty'], "cost"=>$value['cost'], "timeslot"=>$datetime, "address"=>$value['address']);
                array_push($orders, $itemJSON);
            }
        }

        $toSend = json_encode(array("orders"=>$orders));

        $_SESSION["toSend"] = $toSend;
    ?>
    
    <div id="paypal-button-container">

    <!-- Include the PayPal JavaScript SDK -->
    <script src="https://www.paypal.com/sdk/js?client-id=AXLFDRCudt0t_lqQ9fZf5fayRG_OZLjHcovVY3rfGV7L774-uf98C9PQYF1Wx8GS-DtAJXEyE61EFYzb&currency=SGD"></script>

    <script>
        // Render the PayPal button into #paypal-button-container
        paypal.Buttons({

            // Set up the transaction
            createOrder: function(data, actions) {
                return actions.order.create({
                    purchase_units: [{
                        amount: {
                            value: "<?php echo $_SESSION['cart']['totalCost'];?>"
                        }
                    }]
                });
            },

            // Finalize the transaction
            onApprove: function(data, actions) {
                return actions.order.capture().then(function(details) {
                    // Show a success message to the buyer
                    alert('Transaction completed!');
                    window.location.pathname = "/ESD_Application/frontend/drwhoui/ordering/checkoutFinal.php";
                });
            }


        }).render('#paypal-button-container');
    </script>

    </div>

</body>
</html>
