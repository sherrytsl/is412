<?php
    session_start();
    if (!isset($_SESSION)){
        header("Location: ../login-logout/index.php");
        exit();
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../../css/stylesheet.css">
    <link rel="stylesheet" type="text/css" href="../css/stylesheet.css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400&display=swap" rel="stylesheet">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>

    <title>Dr Who UI</title>
</head>
<body>
    <header>
        <h1 class="logo">Dr. WHO UI</h1>
        <nav>
            <ul class="nav_links">
                <li><a href="../whoindex.php" onclick="sendData()">My Profile</a></li>
                <li><a href="drwhoorder.php" onclick="sendData()" class="current">Place an Order</a></li>
                <li><a href="../drwhopending.php" onclick="sendData()">Pending/ Completed Order</a></li>
                <li><a href="cart.php" onclick="sendData()">Your Cart</a></li>
            </ul>
        </nav>
        <a class="cta" href="../../login-logout/logout.php"><button>Logout</button></a>
    </header>

    <div class="drug_filter" style="text-align:center; padding: 50px">
        <h3>Drug Filters</h3>
        <table id="drug_types">

        </table>
    </div>

    <div class="filter_table" style="text-align:center; padding: 20px">
        <table id="filtered_table" style="text-align:center; margin:'auto'; padding:'30px'">
            <tr>
                <th width='10%'>Drug Code</th>
                <th width='15%'>Name</th>
                <th width='35%'>Description</th>
                <th width='15%'>Type</th>
                <th width='10%'>Quantity Left</th>
                <th width='10%'>Cost</th>
                <th width="10%">To Buy</th>
            </tr>
            <tbody class='drugDataTable'>
            </tbody>
        </table>
    </div>

    <script>
        // insert microservice to retrieve approved drugs for user
        var userAppDrugs;
        var userAddress;
        async function funcs(){
            var email = '<?php echo $_SESSION["email"]?>';
            var serviceURL1 = "http://127.0.0.1:5002/customer/" + email;

            var serviceURL2 = "http://127.0.0.1:5002/customer1/" + email;

            try {
                const response =
                    await fetch(
                        serviceURL1, {
                            method: 'GET',
                    });

                const data1 = await response.json();
                const userData1 = data1.users;
                
                userAppDrugs = userData1.approved_drugs.split(", ");
                userAddress = userData1.address;

                var filterRows = "";

                for (var i=0; i<userAppDrugs.length; i++){
                    var para = userAppDrugs[i];
                    filterRows += "<td><button onclick=getDrugs('" + para + "')>" + userAppDrugs[i] + "</button></td>";
                }

                $('#drug_types').append("<tr>" + filterRows + "</tr>").css({'text-align': 'center', 'margin-left': 'auto', 'margin-right': 'auto'});

                // show all drugs in filtered_table through information retrieved from microservice data2.inventory + form qty submit
                const response1 =
                    await fetch(
                        serviceURL2, {
                            method: 'GET',
                    });

                const data2 = await response1.json();
                // console.log(data2);
                const userDrugs = data2.approved_drugs.inventory;
                // console.log(userDrugs);
                
                var filteredTable = "";

                for (var i=0; i<userDrugs.length; i++){
                    if (userAppDrugs.includes(userDrugs[i].drug_type)){
                        filteredTable += "<tr class='" + userDrugs[i].drug_type + "'>\
                                            <td>" + userDrugs[i].drugID + "</td>\
                                            <td>" + userDrugs[i].name + "</td>\
                                            <td>" + userDrugs[i].drug_description + "</td>\
                                            <td>" + userDrugs[i].drug_type + "</td>\
                                            <td>" + userDrugs[i].quantity + "</td>\
                                            <td>" + userDrugs[i].price + "</td>\
                                            <td>\
                                                <form>\
                                                    <input type='hidden' id='" + userDrugs[i].name.split(" ").join("_") + "PRICE' value='" + userDrugs[i].price + "'/>\
                                                    <input type='hidden' id='" + userDrugs[i].name.split(" ").join("_") + "QTY' value='" + userDrugs[i].quantity + "'/>\
                                                    Quantity:<input type='number' min='0' max='" + userDrugs[i].quantity + "' id='" + userDrugs[i].name.split(" ").join("_") + "'/></br>\
                                                    <input type='button' value='Add To Cart' onclick='cart(\"" + userDrugs[i].name.split(" ").join("_") + "\")'/>\
                                                </form>\
                                            </td></tr>";
                    }
                }

                $('#filtered_table').append("<tbody>" + filteredTable + "</tbody>").css({'text-align': 'center', 'margin-left': '10%', 'margin-right': '10%'});
            } catch (error){

            };
        }
        window.onload = funcs;

        // function to retrieve drugs by filtered list and hide other filters
        function getDrugs(type) {
            // var rows = $('table.filtered_table tr');
            // var drugType = rows.filter('.'+type).show();
            // rows.not(drugType).hide();
            // console.log(type);
            for (var i=0; i<userAppDrugs.length; i++){
                // console.log(userAppDrugs[i]);
                var para = userAppDrugs[i];
                if (type != para){
                    $('.'+para).hide();
                };
            };
            $('.'+type).show();
        };

        var shopping_cart = {};

        function cart(drug_name){
            if (Number(document.getElementById(drug_name).value) > Number(document.getElementById(drug_name+"QTY").value) || Number(document.getElementById(drug_name).value) < 1){
                alert("Over our stock limit, please enter a valid quantity!");
            } else {
                if (!(drug_name in shopping_cart)){
                    shopping_cart[drug_name] = {};
                    shopping_cart[drug_name]["qty"] = Number(document.getElementById(drug_name).value);
                    shopping_cart[drug_name]["cost"] = Number(document.getElementById(drug_name+"PRICE").value);
                    shopping_cart[drug_name]["stock"] = Number(document.getElementById(drug_name+"QTY").value);
                    shopping_cart[drug_name]["address"] = userAddress;

                } else {
                    shopping_cart[drug_name]["qty"] += Number(document.getElementById(drug_name).value);
                };
            };
            document.getElementById(drug_name).value = "";
        };

        function sendData(){
            document.cookie = "cart=" + JSON.stringify(shopping_cart);
        }
    </script>

</body>
</html>