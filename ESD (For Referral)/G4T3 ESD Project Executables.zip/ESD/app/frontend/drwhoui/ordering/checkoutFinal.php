<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../../css/stylesheet.css">
    <link rel="stylesheet" type="text/css" href="../css/stylesheet.css">
    <title>Checkout Success</title>
</head>
<body>

    <?php
        session_start();
        if (!isset($_SESSION["cart"]) or empty($_SESSION["cart"] or !isset($_SESSION["toSend"]))){
            $_SESSION["checkoutError"] = "<script>alert('Cart is empty!')</script>";
            header("Location: cart.php");
            exit();
        }

        $toSend = $_SESSION["toSend"];
    ?>

    <script type="text/javascript">
        var newOrderID;
        var toSend = <?php echo $toSend;?>;
        for (var i=0; i< toSend.orders.length; i++){
            toSend.orders[i]['userid'] = sessionStorage.getItem('userid');
        }
        async function funcs(){
            var serviceURL1 = "http://127.0.0.1:5008/booking";

            try {
                const response =
                    await fetch(
                        serviceURL1, {
                            method: 'GET',
                    });

                const data1 = await response.json();
                if (data1.orders.length == 0){
                    newOrderID = 101;
                } else {
                    newOrderID = data1.orders[[data1.orders.length-1]].orderid + 1;
                }
            } catch (error){

            };

            var serviceURL2 = "http://127.0.0.1:5008/booking/" + newOrderID;
            try {
                const response =
                    await fetch(
                        serviceURL2, {
                            method: 'POST',
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify(toSend),
                    });

                const data = await response.json();
                if (response.ok) {
                    console.log(data);
                };
            } catch (error){

            };
        }
        window.onload = funcs;
    </script>

    <?php
        unset($_SESSION["cart"]);
        echo "<h2 style='text-align:center; padding-top:150px;'>Order successfully place, awaiting pharmacist review.</h2></br>";
        echo "<div style='text-align:center;'><button onclick='redirect()'>Click here to head back to Dr WHO.</button></div>";
    ?>

    <script>
        function redirect(){
            window.location.pathname = "/ESD_Application/frontend/drwhoui/drwhopending.php";
        }
    </script>

</body>
</html>