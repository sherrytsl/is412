<?php
    session_start();
    if (!isset($_SESSION)){
        header("Location: ../login-logout/index.php");
        exit();
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/stylesheet.css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400&display=swap" rel="stylesheet">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>

    <title>Dr Who UI</title>
</head>
<body>
    <header>
        <h1 class="logo">Dr. WHO UI</h1>
        <nav>
            <ul class="nav_links">
                <li><a href="whoindex.php">My Profile</a></li>
                <li><a href="ordering/drwhoorder.php">Place an Order</a></li>
                <li><a href="drwhopending.php" class="current">Pending/ Completed Order</a></li>
                <li><a href="ordering/cart.php">Your Cart</a></li>
            </ul>
        </nav>
        <a class="cta" href="../login-logout/logout.php"><button>Logout</button></a>
    </header>

    <div class="orderStatfilter" style="text-align:center; padding: 20px">
        <h3>Orders Filters</h3>
        <table id="orderStats" style="margin:auto;">
            <tr>
                <td><button onclick="getStatus('pending')">Pending</button></td>
                <td><button onclick="getStatus('confirmed')">Confirmed</button></td>
            </tr>
        </table>
    </div>

    <div class="orderFilter" style="text-align:center; padding: 50px;">
        <table id="orderFilter" style="margin:auto;">
            <tr>
                <th width="20%">Order ID</th>
                <th width="20%">Status</th>
                <th width="20%">View Order</th>
            </tr>
            <tbody class='orderFiltered'>
            </tbody>
        </table>
    </div>

    <script>
        var ids = [];
        async function funcs(){
            var serviceURL1 = "http://127.0.0.1:5008/booking/pharm/";

            try {
                const response =
                    await fetch(
                        serviceURL1, {
                            method: 'GET',
                    });

                const data1 = await response.json();
                
                const cleanData1 = data1.orders;
                if (cleanData1 == undefined || cleanData1.length == 0){
                    throw "No Pending Orders";
                }

                var orderFilterRows = "";
                
                for (var i=0; i<cleanData1.length; i++){
                    if (!(ids.includes(cleanData1[i].orderid)) && sessionStorage.getItem('userid') == cleanData1[i].userid){
                        orderFilterRows += "<tr class='pending'><td height='50px'>" + cleanData1[i].orderid + "</td><td height='50px'>" + cleanData1[i].status + "</td><td><form action='viewOrder.php' method='POST'><button type='submit' name='orderid' value='" + cleanData1[i].orderid + "'>View Order</button></form></td></tr>";
                        ids.push(cleanData1[i].orderid);
                    };
                };
                if (orderFilterRows == ""){
                    throw "No Pending Orders";
                }

                $('.orderFiltered').append(orderFilterRows);

            } catch (error){
                alert(error);
            };

            var serviceURL2 = "http://127.0.0.1:5008/booking/delivery";

            try {
                const response =
                    await fetch(
                        serviceURL2, {
                            method: 'GET',
                    });

                const data2 = await response.json();
                
                const cleanData2 = data2.orders;
                if (cleanData2 == undefined || cleanData2.length == 0){
                    throw "No confirmed orders";
                }

                var orderFilterRows = "";

                for (var i=0; i<cleanData2.length; i++){
                    if (!(ids.includes(cleanData2[i].orderid)) && sessionStorage.getItem('userid') == cleanData2[i].userid){
                        orderFilterRows += "<tr class='confirmed'><td height='50px'>" + cleanData2[i].orderid + "</td><td height='50px'>" + cleanData2[i].status + "</td><td><form action='viewOrder.php' method='POST'><button type='submit' name='orderid' value='" + cleanData2[i].orderid + "'>View Order</button></form></td></tr>";
                        ids.push(cleanData2[i].orderid);
                    };
                };

                if (orderFilterRows == ""){
                    throw "No Confirmed Orders";
                }

                $('.orderFiltered').append(orderFilterRows);
            } catch (error){
                alert(error);
            };
        };

        window.onload = funcs;

        function getStatus(stat){
            if (stat == "confirmed"){
                $('.pending').hide();
                $('.confirmed').show();
            } else if (stat == "pending"){
                $('.confirmed').hide();
                $('.pending').show();
            }
        }

    </script>
</body>
</html>