<?php
    session_start();
    if (!isset($_SESSION)){
        header("Location: ../login-logout/index.php");
        exit();
    }

    if (isset($_POST["orderid"])){
        $orderid = $_POST["orderid"];
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/stylesheet.css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400&display=swap" rel="stylesheet">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>

    <title>Dr Who UI</title>
</head>
<body>
    <header>
        <h1 class="logo">Dr. WHO UI</h1>
        <nav>
            <ul class="nav_links">
                <li><a href="whoindex.php">My Profile</a></li>
                <li><a href="ordering/drwhoorder.php">Place an Order</a></li>
                <li><a href="drwhopending.php" class="current">Pending/ Completed Order</a></li>
                <li><a href="ordering/cart.php">Your Cart</a></li>
            </ul>
        </nav>
        <a class="cta" href="../login-logout/logout.php"><button>Logout</button></a>
    </header>

    <div class="orderTimeslot" style="text-align:center; padding: 20px">
        <h3>View Order <span style='color:#36d39f'><?php echo $orderid;?></span></h3>
        <table id="timeslot" style="margin:auto;">
            <tr>
                <th>Requested Delivery Date Time</th>
            </tr>
            <tbody>
            </tbody>
            <tr>
                <td><h4>Add Appointment to Google Calender</h4><img src="img/calender.png" width="10%" onclick="addToGCal()" style="cursor: pointer;"></td>
            </tr>

        </table>
    </div>

    <div class="orderDetails" style="text-align:center; padding: 50px;">
        <table id="orderDetails" style="margin:auto;">
            <tr>
                <th width="20%">Drug Name</th>
                <th width="20%">Drug Quantity</th>
            </tr>
            <tbody>
            </tbody>
        </table>
    </div>

    <script>
        var orderTime;

        async function funcs(){
            var serviceURL = "http://127.0.0.1:5008/booking/" + <?php echo $orderid;?>

            try {
                const response =
                    await fetch(
                        serviceURL, {
                            method: 'GET',
                    });

                const order = await response.json();

                const orderDetails = order.orders;

                var orderRows = "";
                var timeslot = "";
                var totalCost = 0;
                var status = "";

                for (var i=0; i<orderDetails.length; i++){
                    orderRows += "<tr><td>" + orderDetails[i].drugsOrdered + "</td><td>" + orderDetails[i].drugQuantity + "</td></tr>";
                    timeslot = orderDetails[i].timeslot;
                    totalCost += orderDetails[i].cost;
                    status = orderDetails[i].status;
                }

                orderTime = timeslot;

                orderRows += "<tr><td colspan='2'><h3>Total Cost:</h3>$" + totalCost + "</td></tr>";

                $('#timeslot').append("<tr><td>" + timeslot + "</td></tr><tr><td><h2 style='color: #36d39f'>" + status + "</h2></td></tr>").css({'text-align': 'center', 'padding-top': '20px'});
                $('#orderDetails').append(orderRows).css({'text-align': 'center', 'padding': '10px 30px 0px 30px'});

            } catch (error){

            }
        }

        window.onload = funcs;

        async function addToGCal(){
            var DT = new Date(orderTime);
            var DT1 = new Date(orderTime);
            DT1.setHours(DT1.getHours()+1);
            var formatDT = DT.toISOString().substr(0,19) + "+08:00";
            var formatDT1 = DT1.toISOString().substr(0,19) + "+08:00";
            // console.log(formatDT);
            // console.log(formatDT1);

            var toSend = {
                "summary": "Dr. WHO Delivery",
                "description": "Drug Order Delivery",
                "reminders": {
                    "userDefault": "True",
                },
                "start": {
                    "timeZone": "Asia/Singapore"
                },
                "end": {
                    "timeZone": "Asia/Singapore"
                }
            }

            toSend.start.dateTime = formatDT;
            toSend.end.dateTime = formatDT;

            // console.log(toSend);

            var serviceURL = "http://127.0.0.1:5010/googlecal/";

            try {
                const response =
                    await fetch(
                        serviceURL, {
                            method: 'POST',
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify(toSend),
                    });

                if (response.ok){
                    console.log("Added to Calender");
                    alert("Appointment has been added to your Google Calender");
                }

                // const data = await response.json();
                // console.log(data);

            } catch (error){
                console.log(error);
            }
        }
    </script>
</body>
</html>