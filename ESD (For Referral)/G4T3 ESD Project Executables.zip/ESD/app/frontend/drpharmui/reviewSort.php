<?php
    session_start();

    if (isset($_POST["accept"])){
        $orderID = $_POST["accept"];

    } else if (isset($_POST["reject"])){
        header("Location: revieworders.php");
        exit();
    }
?>

<script>
    async function acceptOrder(orderID){
        var toSend = {"orders": []};

        var serviceURL = "http://127.0.0.1:5008/booking/pharm/";

        try {
            const response =
                await fetch(
                    serviceURL, {
                        method: 'GET',
                    });
            
            const data1 = await response.json();

            const pendingOrders = data1.orders;

            for (var i=0; i<pendingOrders.length; i++){;
                if (pendingOrders[i].orderid == orderID){
                    toSend["orders"].push(pendingOrders[i]);
                }
            }
        } catch (error){
            console.log("JOKES");
        }

        var serviceURL2 = "http://127.0.0.1:5005/pharmacist/approval/" + orderID;
        try {
            const response =
                await fetch(
                    serviceURL2, {
                        method: 'POST',
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify(toSend),
                });

            const data = await response.json();
            if (response.ok){
                console.log(data);
            }
        } catch (error){
            // console.log(error);
        }
    }
    window.onload = acceptOrder(<?php echo $orderID?>);
</script>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/stylesheet.css">
    <title>Document</title>
</head>
<body>
    <div style="padding: 20% 30% 20% 30%; text-align:center">
        <h2>Order Accepted</h2>
        <button onclick="location.href = 'revieworders.php';">Back to Review Orders</button>
    </div>

</body>
</html>