<?php
    session_start();
    if (empty($_SESSION)){
        header("Location: ../login-logout/index.php");
        exit();
    } 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/stylesheet.css">
    <link rel="stylesheet" type="text/css" href="css/stylesheet.css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400&display=swap" rel="stylesheet">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>

    <title>Dr Pharm UI</title>
</head>
<body>

    <header>
        <h1 class="logo">Dr. Pharm UI</h1>
        <nav>
            <ul class="nav_links">
                <li><a href="pharmindex.php">My Profile</a></li>
                <li><a href="revieworders.php"  class="current">Review Orders</a></li>
            </ul>
        </nav>
        <a href="../login-logout/logout.php"><button>Logout</button></a>
    </header>

    <div class="orderTable">
        <table id="pendingOrders">
            <tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Delivery Time</th>
                <th>Review</th>
            </tr>
            <tbody>
            </tbody>
        </table>
    </div>

    <script>
        var ids = [];
        async function funcs(){
            var serviceURL1 = "http://127.0.0.1:5008/booking/pharm/";

            try {
                const response =
                    await fetch(
                        serviceURL1, {
                            method: 'GET',
                    });

                const data1 = await response.json();
                
                const cleanData1 = data1.orders;


                var pendingOrdersRows = "";

                for (var i=0; i<cleanData1.length; i++){
                    var orderid = cleanData1[i].orderid;
                    var customer = cleanData1[i].userid;
                    var timeslot = cleanData1[i].timeslot;
                    if (!(ids.includes(orderid))){
                        pendingOrdersRows += "<tr><td>" + orderid + "</td><td>" + customer + "</td><td>" + timeslot + "</td><td><form action='review.php' method='POST'><input type='hidden' name='reviewOrderID' value='" + orderid + "'><input type='hidden' name='userID' value='" + customer + "'><button type='submit'>Review</button></form></td></tr>";
                        ids.push(orderid);
                    };
                };
                $('#pendingOrders').append(pendingOrdersRows);

            } catch (error){

            }
        }
        window.onload = funcs;
    </script>
</body>
</html>