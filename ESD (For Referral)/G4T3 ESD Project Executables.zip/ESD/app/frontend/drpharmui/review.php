<?php
    session_start();

    if (isset($_POST["reviewOrderID"]) && isset($_POST['userID'])){
        $orderID = $_POST["reviewOrderID"];
        $userID = $_POST["userID"];
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/stylesheet.css">
    <link rel="stylesheet" type="text/css" href="../css/stylesheet.css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400&display=swap" rel="stylesheet">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>

    <title>Dr Pharm UI</title>
</head>
<body>

    <header>
        <h1 class="logo">Dr. Pharm UI</h1>
        <nav>
            <ul class="nav_links">
                <li><a href="pharmindex.php">My Profile</a></li>
                <li><a href="revieworders.php" class="current">Review Orders</a></li>
            </ul>
        </nav>
        <a href="../login-logout/logout.php"><button>Logout</button></a>
    </header>

    <div style="text-align:center; padding: 20px">
        <h3>Review for Order ID <span style="color:#36d39f;"><?php echo $orderID;?></span></h3>
        <table id="userDetails">
            <tr>
                <th>Name</th>
                <th>Gender</th>
                <th>Health Records</th>
                <th>Approved Drugs</th>
            </tr>
            <tbody>
            </tbody>
        </table>

        <table id="orderDetails">
            <tr>
                <th>Drug Name</th>
                <th>Quantity</th>
            </tr>
        </table>
    </div>
    
    <table id="approvalTable">
        <form action="reviewSort.php" method="POST">
        <tr>
            <td><button type="submit" name="accept" <?php echo "value='$orderID'"?>>Accept Order</button></td>
        </tr>
        <tr>
            <td colspan="2">Type NIL for Accepted Orders, and Reason for Rejected Orders</br><input type="text" name="reason" placeholder="Reason for Rejecting Order" size="50%" required></td>
        </tr>
        <tr>
            <td><button name="reject" onclick="alert('Assume all orders are approved!')" style="background-color:#ff6961;">Reject Order</button></td>
        </tr>
        </form>
    </table>

    <script>
        async function funcs(){
            var serviceURL1 = "http://127.0.0.1:5002/customer";
            var orderID = '<?php echo $orderID;?>';
            var userID = '<?php echo $userID;?>';

            try {
                const response =
                    await fetch(
                        serviceURL1, {
                            method: 'GET',
                    });

                const data1 = await response.json();
                const userData1 = data1.users;

                var name = "";
                var gender = "";
                var healthRecords = "";
                var approvedDrugs = "";
                
                for (var i=0; i<userData1.length; i++){
                    if (userData1[i].userID == userID){
                        name = userData1[i].name;
                        gender = userData1[i].gender;
                        healthRecords = userData1[i].health_records;
                        approvedDrugs = userData1[i].approved_drugs;
                        break;
                    }
                }

                healthRecords = healthRecords.split(", ").join("</br>");
                approvedDrugs = approvedDrugs.split(", ").join("</br>");

                $('#userDetails').append("<tr><td>" + name + "</td><td>" + gender + "</td><td>" + healthRecords + "</td><td>" + approvedDrugs + "</td></tr>");
                
            } catch (error){
                console.log(error);
            };

            var serviceURL2 = "http://127.0.0.1:5008/booking/pharm/";

            try {
                const response =
                    await fetch(
                        serviceURL2, {
                            method: 'GET',
                    });

                const data2 = await response.json();

                const orderData = data2.orders;

                var orderDataRows = "";
                for (var i=0; i<orderData.length; i++){
                    if (orderID == orderData[i].orderid){
                        orderDataRows += "<tr><td>" + orderData[i].drugsOrdered + "</td><td>" + orderData[i].drugQuantity + "</td></tr>";
                    }
                }

                $('#orderDetails').append(orderDataRows);

            } catch (error){

            };
        };

        window.onload = funcs;
    </script>


</body>
</html>