<?php
    include("config.php");

    $login_button = "";

    if (isset($_GET["code"])){
        $token = $google_client->fetchAccessTokenWithAuthCode($_GET["code"]);

        if(!isset($token["error"])){
            $google_client->setAccessToken($token["access_token"]);

            $_SESSION["access_token"] = $token["access_token"];

            $google_service = new Google_Service_Oauth2($google_client);

            $data = $google_service->userinfo->get();

            if(!empty($data["given_name"])){
                $_SESSION["given_name"] = $data["given_name"];
            }

            if (!empty($data["family_name"])){
                $_SESSION["surname"] = $data["family_name"];
            }

            if (!empty($data["email"])){
                $_SESSION["email"] = $data["email"];
            }

            if (!empty($data["picture"])){
                $_SESSION["picture"] = $data["picture"];
            }
        }
    }

    if (!isset($_SESSION["access_token"])){
        $login_button = "<a href='".$google_client->createAuthUrl()."'><img src='img/google-icon.svg' id='g-btn'/></a>";
    }
?>
<!DOCTYPE html>
<html lang="en">    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/stylesheet.css">
    <script src="https://kit.fontawesome.com/4626c08766.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400&display=swap" rel="stylesheet">
    <title>Dr. WHO Login</title>
</head>
<body>
    <img class="background" src="img/Background.png">
    <div class="container">
        <div class="img">
            <img src="img/Doctors.svg">
        </div>
        <div class="login-container">
            <form method="POST" action="authenticate.php">
                <img class="login_img" src="img/Delivery.svg">
                <h2>Welcome</h2>
                <div class="input-div one">
                    <div class="i">
                        <i class="fas fa-user"></i>
                    </div>
                    <div>
                        <h5>Username</h5>
                        <input class="input" type="text" id="username" name="username">
                    </div>
                </div>
                <div class="input-div two">
                    <div class="i">
                        <i class="fas fa-lock"></i>
                    </div>
                    <div>
                        <h5>Password</h5>
                        <input class="input" type="password" id="password" name="password">
                    </div>
                </div>
                <a href="#">Forgot Password</a>
                <input type="submit" class="btn" value="Login" id="submit">
                <?php
                    if (!empty($_SESSION["error"])){
                        echo $_SESSION["error"];
                        $_SESSION["error"] = "";
                    }
                    
                    if ($login_button == ""){
                        header("Location: authenticate.php");
                    } else {
                        echo $login_button;
                    }
                ?>
            </form>
        </div>
    </div>
    <script type="text/javascript" src="js/main.js"></script>
</body>
</html>