<?php
    session_start();
?>

<script>
    async function funcs(){
        var email = '<?php echo $_SESSION["email"]?>';
        var serviceURL = "http://127.0.0.1:5000/login/" + email;

        try {
            const response = 
                await fetch (
                    serviceURL, {
                        method: 'GET',
                    }
                );


            const data = await response.json();

            var usertype = data.usertype;

            if (usertype == "customer"){
                var serviceURL1 = "http://127.0.0.1:5002/customer/" + email;

                try {
                    const response =
                        await fetch(
                            serviceURL1, {
                                method: 'GET',
                        });

                const data1 = await response.json();
                
                const userid = data1.users.userID;
                sessionStorage.setItem("userid", userid);
                } catch (error){

                };
                window.location.pathname = '/ESD_Application/frontend/drwhoui/whoindex.php';

            } else if (usertype == "pharmacist"){
                window.location.pathname = '/ESD_Application/frontend/drpharmui/pharmindex.php';

            } else if (usertype == "deliveryman"){
                window.location.pathname = '/ESD_Application/frontend/drdeliveryui/deliveryindex.php'

            } else {
                window.location.pathname = '/ESD_Application/frontend/login-logout/logout.php';
            }
        } catch (error) {

        };
    }
    window.onload = funcs;
</script>