from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS, cross_origin
from os import environ

import json
import sys
import os
import pika
import requests

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = environ.get('dbURL')
# create the DB and change the url
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['CORS_HEADERS'] = 'Content-Type'
 
db = SQLAlchemy(app)
CORS(app, support_credentials=True)


# bookingURL = "http://localhost:5001/"

class Booking(db.Model):
    __tablename__ = 'booking'

    orderid = db.Column(db.Integer, primary_key=True)
    userid = db.Column(db.String(50), nullable = False)
    drugsOrdered = db.Column(db.String(100), primary_key=True)
    drugQuantity = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(100), nullable=False)
    timeslot = db.Column(db.DateTime, nullable=False)
    cost = db.Column(db.Float(), nullable = False)
    address = db.Column(db.String(50), nullable = False)

    def __init__(self, orderid, userid, drugsOrdered, drugQuantity, status, timeslot, cost, address):
        self.orderid = orderid
        self.userid = userid
        self.drugsOrdered = drugsOrdered
        self.drugQuantity = drugQuantity
        self.status = status
        self.timeslot = timeslot
        self.cost = cost
        self.address = address

    def json(self):
        return {
            'orderid': self.orderid,
            'userid': self.userid, 
            'drugsOrdered': self.drugsOrdered,
            'drugQuantity': self.drugQuantity,
            'status': self.status,
            'timeslot': self.timeslot,
            'cost': self.cost,
            'address': self.address
        }
    
    def getTimeslot(self):
        return self.timeslot

@app.route("/booking/")
@cross_origin(supports_credentials=True)
def getAllOrders():
    return {'orders': [order.json() for order in Booking.query.all()]}


@app.route('/booking/<string:request_id>', methods=['GET'])
@cross_origin(supports_credentials=True)
def find_order_details(request_id):

    orders = Booking.query.filter_by(orderid=request_id).all()

    if orders:
        return {'orders': [order.json() for order in orders]}
    return ({"Message": "Order not found."}),404


@app.route('/booking/<string:newid>', methods=['POST'])
@cross_origin(supports_credentials=True)
def createNewOrder(newid):
    
    data = request.get_json()
    
    orders = data['orders']
    order = Booking.query.filter_by(orderid=newid).first()
    if(order):
        return {'message': 'orderID already exists'},502
        
    for index, value in enumerate(orders):
        if 'drug' in orders[index] and 'quantity' in orders[index]:
            # print(index, value)
            order = Booking(newid, orders[index]['userid'], orders[index]['drug'], orders[index]['quantity'],'pending', orders[index]['timeslot'], orders[index]['cost'], orders[index]['address'] )
            db.session.add(order)
            
        else:
            return {'message': 'Invalid Input'},400
        
    try:
        db.session.commit()
    except Exception as e: 
        return {"message": "An error occured when adding to the database"}, 500
        # book = Booking(newid, drug, quantity)

    return {"message":"Success", "status":"pending"},201

@app.route('/booking/pharm/', methods=["GET"])
@cross_origin(supports_credentials=True)
def retrievePending():
    orders = Booking.query.filter_by(status='pending').all()
    
    if orders:
        return {'orders': [order.json() for order in orders]}
    return ({"Message": "Order not found."}),404

@app.route('/booking/delivery/', methods=["GET"])
@cross_origin(supports_credentials=True)
def retrieveConfirmed():
    orders = Booking.query.filter_by(status='confirmed').all()
    
    if orders:
        temp = {'orders': [order.json() for order in orders]}
        sendDeliveryMan(temp)
        return temp
    return ({"Message": "Order not found."}),404

# @app.route("/booking/delivery/temp", methods=["GET"])
def sendDeliveryMan(inp):
    print()
    result = inp
    # print(result)

    hostname = "172.17.0.3" # default hostname
    port = 5672 # default port
    connection = pika.BlockingConnection(pika.ConnectionParameters(host=hostname, port=port))
    channel = connection.channel()

    # set up the exchange if the exchange doesn't exist
    exchangename="booking_deliveryman_updatedb"
    channel.exchange_declare(exchange=exchangename, exchange_type='direct')

    message = json.dumps(result, default=str)
  
    # channel.basic_publish(exchange=exchangename, routing_key="schedule.update", body=message)

    replyqueuename = "booking_deliveryman_reply"
        # inform Booking and exit
        # prepare the channel and send a message to Booking
    channel.queue_declare(queue='deliveryman', durable=True) 
    channel.queue_bind(exchange=exchangename, queue='deliveryman', routing_key='deliveryman.updatedb') 
    channel.basic_publish(exchange=exchangename, routing_key="deliveryman.updatedb", body=message,
     properties=pika.BasicProperties(delivery_mode = 1, # make message persistent within the matching queues until it is received by some receiver (the matching queues have to exist and be durable and bound to the exchange, which are ensured by the previous two api calls)
                reply_to=replyqueuename, # set the reply queue which will be used as the routing key for reply messages
                 # set the correlation id for easier matching of replies
            ))
    
    print("Approval sent to deliveryman.")
    # close the connection to the broker
    connection.close()

    return result

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5008, debug=True)