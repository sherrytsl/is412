from flask import Flask, request, jsonify, current_app
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS, cross_origin
# from customer import User

import json
import sys
import os
import random

import pika


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root@localhost:3306/customer'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False



db = SQLAlchemy(app)
CORS(app, support_credentials=True)

class User(db.Model):
    __tablename__ = 'customer'
    
    userID = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), nullable=False)
    gender = db.Column(db.String(64), nullable=False)
    health_records = db.Column(db.String(256), nullable=False)
    approved_drugs = db.Column(db.String(256), nullable=False)
    address = db.Column(db.String(256), nullable=False)
    email = db.Column(db.String(256), nullable=False)
 
    def __init__(self, userID, name, gender, health_records, approved_drugs , address, email):
        self.userID = userID
        self.name = name
        self.gender = gender
        self.health_records = health_records
        self.approved_drugs = approved_drugs
        self.address = address
        self.email = email
 
    def json(self):
        return {"userID": self.userID, "name": self.name, "gender": self.gender, "health_records": self.health_records, "approved_drugs": self.approved_drugs, "address": self.address, "email": self.email}


def get_address_by_userID(userID):
    user = User.query.filter_by(userID = userID)
    for u in user:
        return u.address
    
    userID_error(userID)
    return 'No address found for: ' + str(userID) + ", userID incorrect."

def get_email_by_userID(userID):
    user = User.query.filter_by(userID = userID)
    for u in user:
        return u.email
    
    userID_error(userID)
    return 'No address found for: ' + str(userID) + ", userID incorrect."

def userID_error(userID):
    
    message = "Error 1a: No records found for userID: " + userID
    channel.queue_declare(queue='error_handler', durable=True) # make sure the queue used by the error handler exist and durable
    channel.queue_bind(exchange=exchangename, queue='error_handler', routing_key='throw.error') # make sure the queue is bound to the exchange
    channel.basic_publish(exchange=exchangename, routing_key='throw.error', body=message,
        properties=pika.BasicProperties(delivery_mode = 2) # make message persistent within the matching queues until it is received by some receiver (the matching queues have to exist and be durable and bound to the exchange)
    )
    print("No userID found, sent to error handler.")

hostname = "localhost"
port = 5672
connection = pika.BlockingConnection(pika.ConnectionParameters(host=hostname, port=port))
channel = connection.channel()
exchangename="deliveryman_direct"
channel.exchange_declare(exchange=exchangename, exchange_type='direct')


# USER SCENARIO 3 NEW STEPS, Communications between deliveryman and customer

# Function to receive User ID from Deliverman and to return address
def receiveOrder():
    # prepare a queue for receiving messages
    channelqueue = channel.queue_declare(queue="deliveryman_customer2", durable=True) # 'durable' makes the queue survive broker restarts so that the messages in it survive broker restarts too
    queue_name = channelqueue.method.queue
    channel.queue_bind(exchange=exchangename, queue=queue_name, routing_key='deliveryman.request2') # bind the queue to the exchange via the key
    # set up a consumer and start to wait for coming messages
    channel.basic_qos(prefetch_count=1) # The "Quality of Service" setting makes the broker distribute only one message to a consumer if the consumer is available (i.e., having finished processing and acknowledged all previous messages that it receives)
    channel.basic_consume(queue=queue_name, on_message_callback=callback)
    print("Waiting for messages to consume...")
    channel.start_consuming() 
    
def callback(channel, method, properties, body): # required signature for the callback; no return
    print("Received User ID from " + __file__)

    temp = {}
    address = get_address_by_userID(body.decode())
    email = get_email_by_userID(body.decode())
    temp["email"] = email
    temp["address"] = address
    replymessage = json.dumps(temp, default=str)
    # replymessage = temp

    # replymessage = get_address_by_userID(body.decode()) # convert the JSON object to a string
    print("--------")
    print(type(replymessage))
    print(replymessage)
    print("--------")
    reply_queue_name = "customer_deliveryman6"
    
    channel.queue_declare(queue=reply_queue_name, durable=True) # make sure the queue used for "reply_to" is durable for reply messages
    channel.queue_bind(exchange=exchangename, queue=reply_queue_name, routing_key="deliveryman.reply6") # make sure the reply_to queue is bound to the exchange
    channel.basic_publish(exchange=exchangename,
            routing_key="deliveryman.reply6", # use the reply queue set in the request message as the routing key for reply messages
            body=replymessage, 
            properties=pika.BasicProperties(delivery_mode = 2),
    )
    channel.basic_ack(delivery_tag=method.delivery_tag) # acknowledge to the broker that the processing of the request message is completed
    # print(replymessage)

if __name__ == '__main__':
    receiveOrder()
