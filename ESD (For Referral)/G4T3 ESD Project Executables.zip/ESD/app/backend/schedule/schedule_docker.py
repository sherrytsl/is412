from flask import Flask, request, jsonify, make_response
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS, cross_origin
from datetime import datetime as dt
from os import environ

import json

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = environ.get('dbURL')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['CORS_HEADERS'] = 'Content-Type'


db = SQLAlchemy(app)
CORS(app)


class Schedule(db.Model):
    __tablename__ = 'schedule'
    # Data Type: Accepts one of the following: String(size), Text, DateTime, Float, Boolean, PickleType, or LargeBinary.
    dt = db.Column(db.DateTime, primary_key=True)
    status = db.Column(db.String(15), nullable=False)
    count = db.Column(db.Integer(), nullable=False)

    def __init__(self, dt, status, count):
        self.dt = dt
        self.status = status
        self.count = count

    
    def json(self):
        #convert to json format 
        return {"date time": self.dt, "status": self.status}


@app.route("/")
@cross_origin(supports_credentials=True)
def home():
    return "works"

@app.route("/schedule",methods = ['GET'])
@cross_origin(supports_credentials=True)
def get_schedule():
    #return all timeslots
    # return jsonify({"available timeslots": [each.json() for each in Schedule.query.all()]})

    #return all AVAILABLE timeslots
    available = Schedule.query.filter(Schedule.status == 'available').all()
    return jsonify({"available timeslots": [each.json() for each in available]}), 200
    


@app.route("/schedule", methods = ["POST"])
@cross_origin(supports_credentials=True)
def update_schedule():
    """ 
    update the status of a time slot
    json body input is in this format
    {
        "date time": "2020-04-14 11:30:00",
        "status": "pending"
    }
    """
    data = request.get_json()
    new = Schedule.query.filter_by(dt=data['date time']).first()
    
    try:
        new = Schedule.query.filter_by(dt=data['date time']).first()
        new.status=data['status']
        db.session.commit()
        return jsonify({"message": "update success."}), 200
    except:
        return jsonify({"message": "An error occurred updating schedule."}), 500



@app.route("/get_status")
@cross_origin(supports_credentials=True)
def get_status():
    did = request.args.get('did')
    existing = Schedule.query.filter(Schedule.did == did).first()
    if existing is not None:
        return existing.json()
    return "check your input values"




@app.route("/add", methods=['GET'])
@cross_origin(supports_credentials=True)
def add():
    did = request.args.get('did')
    if did is not None:
        try:
            new = Schedule(did = did, dt = dt.now(), status='in progress', count=0)
            db.session.add(new)
            db.session.commit()
            return make_response(f"new delivery with id {did} successfully created")
        except Exception as e:
            return str(e)
    return "check your input parameters"




# @app.route("/book/<string:isbn13>", methods=['POST'])
# def create_book(isbn13):
#     if (Book.query.filter_by(isbn13=isbn13).first()):
#         return jsonify({"message": "A book with isbn13 '{}' already exists.".format(isbn13)}), 400

#     data = request.get_json()
#     print(data)
#     book = Book(isbn13, **data)
    

#     try:
#         db.session.add(book)
#         db.session.commit()
#     except:
#         return jsonify({"message": "An error occurred creating the book."}), 500

#     return jsonify(book.json()), 201

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5003, debug=True)

