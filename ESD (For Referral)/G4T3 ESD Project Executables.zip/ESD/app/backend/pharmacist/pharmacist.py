from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS, cross_origin
from os import environ


import json
import pika
import requests

app = Flask(__name__)
 

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root@localhost:3306/pharmacist'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['CORS_HEADERS'] = 'Content-Type'
 
db = SQLAlchemy(app)
CORS(app, support_credentials=True)

#stuff to activate AMQP with error_handler
hostname = "localhost"
port = 5672
connection = pika.BlockingConnection(pika.ConnectionParameters(host=hostname, port=port))
channel = connection.channel()
exchangename="customer_direct"
channel.exchange_declare(exchange=exchangename, exchange_type='direct')
 
class Pharmacist(db.Model):
    __tablename__ = 'pharmacist'
    orderID = db.Column(db.Integer, primary_key=True)
    userID = db.Column(db.String(64), nullable=False )
    name = db.Column(db.String(64), nullable=False)
    status = db.Column(db.String(64), nullable=False)
    remarks = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(256), nullable=False)
    
    def __init__(self, orderID, pharmacistID, name, status, remarks, email):
        self.orderID = orderID
        self.userID = userID
        self.name = name
        self.status = status
        self.remarks = remarks
        self.email = email

    def json(self):
        return {"orderID": self.orderID, "userID": self.userID, "name": self.name, "status": self.status, "remarks": self.remarks, "email":self.email}

 
# Get all Pharmacists
@app.route("/pharmacist")
@cross_origin(supports_credentials=True)
def get_all():
    return jsonify({"pharmacist": [pharmacist.json() for pharmacist in Pharmacist.query.all()]})

# Get by order
@app.route("/pharmacist/<string:orderID>")
@cross_origin(supports_credentials=True)
def find_by_orderID(orderID):
    order = Pharmacist.query.filter_by(orderID=orderID).first()
    if order:
        return jsonify(order.json())
    order_id_error(orderID)
    return jsonify({"message": "Order not found."}), 404

def order_id_error(orderID):
    message = "Error 2b: No records found for Order ID: " + orderID
    channel.queue_declare(queue='error_handler', durable=True) # make sure the queue used by the error handler exist and durable
    channel.queue_bind(exchange=exchangename, queue='error_handler', routing_key='throw.error') # make sure the queue is bound to the exchange
    channel.basic_publish(exchange=exchangename, routing_key='throw.error', body=message,
        properties=pika.BasicProperties(delivery_mode = 2) # make message persistent within the matching queues until it is received by some receiver (the matching queues have to exist and be durable and bound to the exchange)
    )
    print("No order record found, sent to error handler.")

# Posting an Approval 
@app.route("/pharmacist/<string:orderID>", methods=['POST'])
@cross_origin(supports_credentials=True)
def give_approval(orderID):
    # This is to check if there is an approval for the specific order ID
    if (Pharmacist.query.filter_by(orderID=orderID).first()):
        return jsonify({"message": "Approval History for Order ID '{}' already exists.".format(orderID)}), 400

    data = request.get_json() 
    approval = Pharmacist(orderID, **data) 

    try:
        db.session.add(approval)
        db.session.commit()

    except:
        return jsonify({"message": "An error occurred creating the approval"}), 500
    return jsonify(approval.json()), 201



@app.route('/pharmacist/approval/<string:inp>', methods=['POST'])
@cross_origin(supports_credentials=True)
def send_approval(inp):
#    """inform Booking as needed"""
    # default username / password to the broker are both 'guest'
    hostname = "localhost" 
    port = 5672 # default messaging port.
  
    connection = pika.BlockingConnection(pika.ConnectionParameters(host=hostname, port=port))
    channel = connection.channel()

    # set up the exchange if the exchange doesn't exist
    exchangename="pharmacist_booking_update"
    channel.exchange_declare(exchange=exchangename, exchange_type='direct')
    
    temp = {}
    temp['id'] = inp
    message = json.dumps(temp, default=str)
  
    # channel.basic_publish(exchange=exchangename, routing_key="pharmacist.update", body=message)

    replyqueuename = "pharmacist_booking_reply"
        # inform Booking and exit
        # prepare the channel and send a message to Booking
    channel.queue_declare(queue='booking', durable=True) 
    channel.queue_bind(exchange=exchangename, queue='booking', routing_key='pharmacist.update') 
    channel.basic_publish(exchange=exchangename, routing_key="pharmacist.update", body=message,
     properties=pika.BasicProperties(delivery_mode = 2,))
    
    print("Approval sent to booking.")
    # close the connection to the broker
    connection.close()
    return ({"message": "Approval sent to booking"}),201

if __name__ == '__main__':
    app.run(port=5005, debug=True)
    # send_approval()
