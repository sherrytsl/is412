#!/usr/bin/env python3
# The above shebang (#!) operator tells Unix-like environments
# to run this file as a python3 script
from os import environ

import json
import sys
import os

# Communication patterns:
# Use a message-broker with 'direct' exchange to enable interaction
import pika

# error handling for all errors sent via all Microservices, differentiate via message printed
# always route to throw.error
def receive_error():
    hostname = "localhost" # default broker hostname
    port = 5672 # default port
    # connect to the broker and set up a communication channel in the connection
    connection = pika.BlockingConnection(pika.ConnectionParameters(host=hostname, port=port))
    channel = connection.channel()

    # set up the exchange if the exchange doesn't exist
    exchangename="customer_direct"
    channel.exchange_declare(exchange=exchangename, exchange_type='direct')

    # prepare a queue for receiving messages
    channelqueue = channel.queue_declare(queue="error_handler", durable=True) # 'durable' makes the queue survive broker restarts
    queue_name = channelqueue.method.queue
    channel.queue_bind(exchange=exchangename, queue=queue_name, routing_key='throw.error') # bind the queue to the exchange via the key

    # set up a consumer and start to wait for coming messages
    channel.basic_consume(queue=queue_name, on_message_callback=callback, auto_ack=True)
    channel.start_consuming() # an implicit loop waiting to receive messages; it doesn't exit by default. Use Ctrl+C in the command window to terminate it.

def callback(channel, method, properties, body): # required signature for the callback; no return
    print("Received an request error by " + __file__)
    # print("----")
    # print(type(body))
    # print(body)
    print("Error received below:")
    print(body.decode()) # print a new line feed

# def process_health_request_error(ID):
#     print("Processing an request error: no health record found for ID below")
#     print(ID)
    
# # error handling for Inventory US1 (step 3)
# def return_inventory_error():
#     hostname = "localhost" # default broker hostname
#     port = 5672 # default port
#     # connect to the broker and set up a communication channel in the connection
#     connection = pika.BlockingConnection(pika.ConnectionParameters(host=hostname, port=port))
#     channel = connection.channel()

#     # set up the exchange if the exchange doesn't exist
#     exchangename="customer_direct"
#     channel.exchange_declare(exchange=exchangename, exchange_type='direct')

#     # prepare a queue for receiving messages
#     channelqueue = channel.queue_declare(queue="error_handler2", durable=True) # 'durable' makes the queue survive broker restarts
#     queue_name = channelqueue.method.queue
#     channel.queue_bind(exchange=exchangename, queue=queue_name, routing_key='throw.error') # bind the queue to the exchange via the key

#     # set up a consumer and start to wait for coming messages
#     channel.basic_consume(queue=queue_name, on_message_callback=callback2, auto_ack=True)
#     channel.start_consuming() # an implicit loop waiting to receive messages; it doesn't exit by default. Use Ctrl+C in the command window to terminate it.

# def callback2(channel, method, properties, body): # required signature for the callback; no return
#     print("Received an order error by " + __file__)
#     process_inventory_error(json.loads(body))
#     print() # print a new line feed

# def process_inventory_error(inventory):
#     print("Processing an inventory error: no approved drugs returned")
#     print(inventory)


if __name__ == "__main__":  # execute this program only if it is run as a script (not by 'import')
    print("This is " + os.path.basename(__file__) + ": processing an order error...")
    receive_error()