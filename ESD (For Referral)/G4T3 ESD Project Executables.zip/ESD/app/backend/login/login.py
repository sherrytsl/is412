from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS, cross_origin

import json
import pika
import requests

app = Flask(__name__)
CORS(app, support_credentials=True)
 

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root@localhost:3306/login'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
 
db = SQLAlchemy(app)
 
class Login(db.Model):
    __tablename__ = 'login'

    email = db.Column(db.String(64), primary_key=True)
    usertype = db.Column(db.String(64), nullable=False)
    
    def __init__(self, email, usertype):
        self.email = email
        self.usertype = usertype
     
    def json(self):
        return {"email": self.email, "usertype": self.usertype}

 
# Get all login credentials for all user types
@app.route("/login")
@cross_origin(supports_credentials=True)
def get_all():
    return jsonify({"login": [login.json() for login in Login.query.all()]})


#Get a certain login credential for a particular email
@app.route("/login/<string:email>")
@cross_origin(supports_credentials=True)
def find_by_email(email):
    email = Login.query.filter_by(email=email).first()
    if email:
        return jsonify(email.json())
    return jsonify({"message": "Email not found."}), 404


if __name__ == '__main__':
    app.run(port=5000, debug=False)