from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
# from deliveryman import Delive/ryman
from os import environ


import json
import sys
import os
import random

# Communication patterns:
# Use a message-broker with 'direct' exchange to enable interaction
import pika

userinfo = None

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root@localhost:3306/deliveryman' 
# create the DB and change the url
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
 
db = SQLAlchemy(app)
CORS(app)

class Deliveryman(db.Model):
    __tablename__ = 'deliveryman'
    # Data Type: Accepts one of the following: String(size), Text, DateTime, Float, Boolean, PickleType, or LargeBinary, Integer.
    customerName = db.Column(db.String(25), nullable=False)
    orderid = db.Column(db.Integer, primary_key=True)
    status = db.Column(db.String(15), nullable=False)
    email = db.Column(db.String(50), nullable=True)
    address = db.Column(db.String(50), nullable=False)
    timeslot = db.Column(db.String(50), nullable=False)

    def __init__(self, orderid, status, email, customerName, address, timeslot):
        self.customerName = customerName
        self.orderid = orderid
        self.status = status
        self.email = email
        self.address = address
        self.timeslot = timeslot
    
    def json(self):
        #convert to json format 
        return {"customerName": self.customerName, "orderid": self.orderid, "status": self.status, "email": self.email, "address": self.address, "timeslot": self.timeslot}
    
def get_all_order():
    deliveryman = Deliveryman.query.all()
    orderDict = {"orderid": []}
    for oid in deliveryman:
        orderDict['orderid'].append(oid.orderid)
    return orderDict

hostname = "localhost" # default hostname
port = 5672 # default port
# connect to the broker and set up a communication channel in the connection

connection = pika.BlockingConnection(pika.ConnectionParameters(host=hostname, port=port))
    # Note: various network firewalls, filters, gateways (e.g., SMU VPN on wifi), may hinder the connections;
    # If "pika.exceptions.AMQPConnectionError" happens, may try again after disconnecting the wifi and/or disabling firewalls

channel = connection.channel()
# set up the exchange if the exchange doesn't exist
exchangename="booking_deliveryman_updatedb"

channel.exchange_declare(exchange=exchangename, exchange_type='direct')

def receiveBooking():

    channelqueue = channel.queue_declare(queue="deliveryman", durable=True) # 'durable' makes the queue survive broker restarts so that the messages in it survive broker restarts too
    queue_name = channelqueue.method.queue
    channel.queue_bind(exchange=exchangename, queue=queue_name, routing_key='deliveryman.updatedb') # bind the queue to the exchange via the key

    # set up a consumer and start to wait for coming messages

    channel.basic_qos(prefetch_count=1) # The "Quality of Service" setting makes the broker distribute only one message to a consumer if the consumer is available (i.e., having finished processing and acknowledged all previous messages that it receives)

    channel.basic_consume(queue=queue_name, on_message_callback=callback)

    channel.start_consuming()
    # print("----Starting----")

def callback(channel, method, properties, body): # required signature for the callback; no return
    # result = updateBooking(json.loads(body))
    print()

    result = updateFromBooking(json.loads(body))
    print(result)
    json.dump(result, sys.stdout, default = str)

    replymessage = json.dumps(result, default=str) # convert the JSON object to a string

    replyqueuename="booking_deliveryman_updatedb"
    
    channel.queue_declare(queue=replyqueuename, durable=True) # make sure the queue used for "reply_to" is durable for reply messages
    channel.queue_bind(exchange=exchangename, queue=replyqueuename, routing_key=replyqueuename) # make sure the reply_to queue is bound to the exchange

    channel.basic_publish(exchange=exchangename,
            routing_key=replyqueuename, # use the reply queue set in the request message as the routing key for reply messages
            body=replymessage, 
    )

    channel.basic_ack(delivery_tag=method.delivery_tag)
    # channel.stop_consuming()


def updateFromBooking(inp):
    orderIDsInDB = get_all_order()['orderid']

    orders = inp

    toAddOID = []
    # sql = "UPDATE booking SET status = 'Confirmed' WHERE orderid =" + inpid
    for value in orders["orders"]:
        print(value)
        # try:
        #     print("Retrieving from Customer")
        #     retrieveFromCustomer(value['userid'])
        # except Exception as e:
        #     return {"message": "An error occured when retrieving from Customer"}, 500
        if value['orderid'] not in orderIDsInDB:
            if value['orderid'] not in toAddOID:

                toAddOID.append(value['orderid'])
                order = Deliveryman(int(value['orderid']) , "Available", "",  value['userid'], value["address"], value['timeslot'])

                db.session.add(order)

    try:
        db.session.commit()
    except Exception as e: 

        return {"message": "An error occured when adding to the database"}, 500
    
    return {"message": "Success"},201

if __name__ == "__main__":  # execute this program only if it is run as a script (not by 'import')
    # app.run(host="0.0.0.0", port=5007, debug=True)
    receiveBooking()
