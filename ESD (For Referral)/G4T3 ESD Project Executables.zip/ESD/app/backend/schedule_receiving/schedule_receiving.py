from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from os import environ

# from schedule import 

import json
import sys
import os
import random

# Communication patterns:
# Use a message-broker with 'direct' exchange to enable interaction
import pika


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root@localhost:3306/schedule' 
# create the DB and change the url
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
 
db = SQLAlchemy(app)
CORS(app)

hostname = "localhost" # default hostname
port = 5672 # default port
# connect to the broker and set up a communication channel in the connection
connection = pika.BlockingConnection(pika.ConnectionParameters(host=hostname, port=port))
    # Note: various network firewalls, filters, gateways (e.g., SMU VPN on wifi), may hinder the connections;
    # If "pika.exceptions.AMQPConnectionError" happens, may try again after disconnecting the wifi and/or disabling firewalls
channel = connection.channel()
# set up the exchange if the exchange doesn't exist
exchangename="booking_schedule_update"
channel.exchange_declare(exchange=exchangename, exchange_type='direct')

def receiveBooking():  
    channelqueue = channel.queue_declare(queue="schedule", durable=True) # 'durable' makes the queue survive broker restarts so that the messages in it survive broker restarts too
    queue_name = channelqueue.method.queue
    channel.queue_bind(exchange=exchangename, queue=queue_name, routing_key='schedule.update') # bind the queue to the exchange via the key

    # set up a consumer and start to wait for coming messages
    channel.basic_qos(prefetch_count=1) # The "Quality of Service" setting makes the broker distribute only one message to a consumer if the consumer is available (i.e., having finished processing and acknowledged all previous messages that it receives)
    channel.basic_consume(queue=queue_name, on_message_callback=callback)
    channel.start_consuming()

def callback(channel, method, properties, body): # required signature for the callback; no return
    # result = updateBooking(json.loads(body))
    print()
    result = updateSchedule(json.loads(body))

    json.dump(result, sys.stdout, default = str)

    replymessage = json.dumps(result, default=str) # convert the JSON object to a string
    replyqueuename="booking_schedule_reply"
    
    channel.queue_declare(queue=replyqueuename, durable=True) # make sure the queue used for "reply_to" is durable for reply messages

    channel.queue_bind(exchange=exchangename, queue=replyqueuename, routing_key=replyqueuename) # make sure the reply_to queue is bound to the exchange
    channel.basic_publish(exchange=exchangename,
            routing_key=replyqueuename, # use the reply queue set in the request message as the routing key for reply messages
            body=replymessage, 
            
    )
    channel.basic_ack(delivery_tag=method.delivery_tag)

# @app.route('/booking/pharmacist/<string:inp>', methods=['GET'])
def updateSchedule(inp):
    print(json.dumps(inp, default = str))
 
    if "timeslot" in inp:
        inpTime = json.dumps(inp["timeslot"], default = str)
    else:
        return "Failed"

    sql = "UPDATE schedule SET `count` = `count`+1 WHERE dt =" + inpTime
    
    db.session.execute(sql)
    try:
        db.session.commit()
    except Exception as e: 
        return('Failed')

    return("Success, updated timeslot")

if __name__ == "__main__":  # execute this program only if it is run as a script (not by 'import')
    # app.run(host="0.0.0.0", port=5002, debug=True)
    receiveBooking()
