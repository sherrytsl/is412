from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
# from deliveryman import Delive/ryman
from os import environ


import json
import sys
import os
import random

# Communication patterns:
# Use a message-broker with 'direct' exchange to enable interaction
import pika

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = environ.get('dbURL') 
# create the DB and change the url
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['CORS_HEADERS'] = 'Content-Type'
 
db = SQLAlchemy(app)
CORS(app)

class Booking(db.Model):
    __tablename__ = 'booking'

    orderid = db.Column(db.Integer, primary_key=True)
    userid = db.Column(db.String(50), nullable = False)
    drugsOrdered = db.Column(db.String(100), primary_key=True)
    drugQuantity = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(100), nullable=False)
    timeslot = db.Column(db.DateTime, nullable=False)
    cost = db.Column(db.Float(), nullable = False)
    address = db.Column(db.String(50), nullable = False)

    def __init__(self, orderid, userid, drugsOrdered, drugQuantity, status, timeslot, cost, address):
        self.orderid = orderid
        self.userid = userid
        self.drugsOrdered = drugsOrdered
        self.drugQuantity = drugQuantity
        self.status = status
        self.timeslot = timeslot
        self.cost = cost
        self.address = address

    def json(self):
        return {
            'orderid': self.orderid,
            'userid': self.userid, 
            'drugsOrdered': self.drugsOrdered,
            'drugQuantity': self.drugQuantity,
            'status': self.status,
            'timeslot': self.timeslot,
            'cost': self.cost,
            'address': self.address
        }
    
    def getTimeslot(self):
        return self.timeslot

# ------------------Set up RabbitMQ Connection-------------------------
hostname = "172.17.0.3" # default hostname
port = 5672 # default port
# connect to the broker and set up a communication channel in the connection

connection = pika.BlockingConnection(pika.ConnectionParameters(host=hostname, port=port))
    # Note: various network firewalls, filters, gateways (e.g., SMU VPN on wifi), may hinder the connections;
    # If "pika.exceptions.AMQPConnectionError" happens, may try again after disconnecting the wifi and/or disabling firewalls

channel = connection.channel()
# set up the exchange if the exchange doesn't exist
exchangename="booking_completed_updatedb"

channel.exchange_declare(exchange=exchangename, exchange_type='direct')
# =====================================================================


def orderCompleted():

    queue_name = "booking_completed"

    channelqueue = channel.queue_declare(queue=queue_name, durable=True) # 'durable' makes the queue survive broker restarts so that the messages in it survive broker restarts too
    queue_name = channelqueue.method.queue
    channel.queue_bind(exchange=exchangename, queue=queue_name, routing_key='booking.completed') # bind the queue to the exchange via the key

    # set up a consumer and start to wait for coming messages

    channel.basic_qos(prefetch_count=1) # The "Quality of Service" setting makes the broker distribute only one message to a consumer if the consumer is available (i.e., having finished processing and acknowledged all previous messages that it receives)

    channel.basic_consume(queue=queue_name, on_message_callback=callback)

    print("WAITING FOR DELIVERYMAN.PY TO SEND COMPLETED BOOKINGS...")
    channel.start_consuming()
    

def callback(channel, method, properties, body): # required signature for the callback; no return
    # result = {'orderID': '108'}
    result = json.loads(body)
    print(result)

    orderID = result['orderID']
    print(orderID)

    sql = 'DELETE FROM booking WHERE `orderid`=' + orderID
    print(sql)

    try:
        db.session.execute(sql)
        db.session.commit()
    except Exception as e:
        print(e)
        return {"message": "delete failed."}, 508
    
    # Acknowledge to Pika that message is received and processed
    channel.basic_ack(delivery_tag=method.delivery_tag)

    # If deleting of orderID is successful, return this
    return {"message": "delete success."}, 200


if __name__ == "__main__":  # execute this program only if it is run as a script (not by 'import')
    # app.run(host="0.0.0.0", port=5007, debug=True)
    orderCompleted()