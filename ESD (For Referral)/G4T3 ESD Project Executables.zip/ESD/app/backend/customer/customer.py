from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS, cross_origin

import json
import sys
import os
import random
# import requests

import pika

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root@localhost:3306/customer'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['CORS_HEADERS'] = 'Content-Type'


db = SQLAlchemy(app)
CORS(app, support_credentials=True)

class User(db.Model):
    __tablename__ = 'customer'
    
    userID = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), nullable=False)
    gender = db.Column(db.String(64), nullable=False)
    health_records = db.Column(db.String(256), nullable=False)
    approved_drugs = db.Column(db.String(256), nullable=False)
    address = db.Column(db.String(256), nullable=False)
    email = db.Column(db.String(256), nullable=False)
 
    def __init__(self, userID, name, gender, health_records, approved_drugs , address, email):
        self.userID = userID
        self.name = name
        self.gender = gender
        self.health_records = health_records
        self.approved_drugs = approved_drugs
        self.address = address
        self.email = email
 
    def json(self):
        return {"userID": self.userID, "name": self.name, "gender": self.gender, "health_records": self.health_records, "approved_drugs": self.approved_drugs, "address": self.address, "email": self.email}


@app.route("/customer")
@cross_origin(supports_credentials=True)
def get_all():
    return jsonify({"users": [user.json() for user in User.query.all()]})

@app.route("/customer/<string:email>")
@cross_origin(supports_credentials=True)
def get_user_by_email(email):
    user = User.query.filter_by(email = email)
    for u in user:
        return jsonify({"users": u.json()})
    
    email_error(email)
    return jsonify({'message': 'Email not found: ' + str(email)})


@app.route("/customer/ID/<string:userID>")
@cross_origin(supports_credentials=True)
def get_address_by_userID(userID):
    user = User.query.filter_by(userID = userID)
    for u in user:
        return u.address
    
    userID_error(userID)
    return {'message': 'userID not found: ' + str(userID)}


# USER SCENARIO 1 (STEPS 1-4)

hostname = "localhost"
port = 5672
connection = pika.BlockingConnection(pika.ConnectionParameters(host=hostname, port=port,heartbeat=65000, blocked_connection_timeout=65000))
channel = connection.channel()
exchangename="customer_direct"
channel.exchange_declare(exchange=exchangename, exchange_type='direct')

approved_drugs_list = None

# USER SCENARIO 1 STEPS 2-4
# Function to invoke direct exchange TOWARDS inventory to reply back list of APPROVED DRUGS
@app.route("/customer1/<string:email>")
@cross_origin(supports_credentials=True)
def get_user_approved_drugs(email):
    user = User.query.filter_by(email = email)
    for u in user:
        send_user_approved_drugs(u.approved_drugs)
        receive_inventory_reply()
        global approved_drugs_list
        return jsonify({"approved_drugs" : approved_drugs_list})
            
    # if no health record found 
    email_error(email)
    return jsonify({'message': 'Email not found: ' + str(email)})

def email_error(email):
    message = "Error 1a: No records found for Email: " + email
    channel.queue_declare(queue='error_handler', durable=True) # make sure the queue used by the error handler exist and durable
    channel.queue_bind(exchange=exchangename, queue='error_handler', routing_key='throw.error') # make sure the queue is bound to the exchange
    channel.basic_publish(exchange=exchangename, routing_key='throw.error', body=message,
        properties=pika.BasicProperties(delivery_mode = 2) # make message persistent within the matching queues until it is received by some receiver (the matching queues have to exist and be durable and bound to the exchange)
    )
    print("No health record found, sent to error handler.")
def userID_error(userID):
    message = "Error 1a: No records found for userID: " + userID
    channel.queue_declare(queue='error_handler', durable=True) # make sure the queue used by the error handler exist and durable
    channel.queue_bind(exchange=exchangename, queue='error_handler', routing_key='throw.error') # make sure the queue is bound to the exchange
    channel.basic_publish(exchange=exchangename, routing_key='throw.error', body=message,
        properties=pika.BasicProperties(delivery_mode = 2) # make message persistent within the matching queues until it is received by some receiver (the matching queues have to exist and be durable and bound to the exchange)
    )
    print("No userID found, sent to error handler.")
def send_user_approved_drugs(user_approved_drugs):
    # prepare the message body content
    # message = json.dumps(user_approved_drugs, default=str) # convert a JSON object to a string
    # user_approved_drugs should be the STRING of approved drugs
    message = user_approved_drugs 
    if message == '{"approved_drugs": ""}': 
        message = '{"approved_drugs": "General"}'
    # print(message)
    
    # convert to dictionary to check if provided approved drugs is empty
    # user_approved_drugs2 = json.loads(message)
    
    # inform Inventory and exit
        # prepare the channel and send a message to Inventory
    channel.queue_declare(queue='customer', durable=True) # make sure the queue used by inventory exist and durable
    channel.queue_bind(exchange=exchangename, queue='customer', routing_key='customer.request') # make sure the queue is bound to the exchange
    channel.basic_publish(exchange=exchangename, routing_key="customer.request", body=message,
        properties=pika.BasicProperties(delivery_mode = 2, # make message persistent within the matching queues until it is received by some receiver (the matching queues have to exist and be durable and bound to the exchange, which are ensured by the previous two api calls)
        )
    )
    print("Order sent to inventory.")
    # connection.close()
    # causes error if uncommented


# Function to receive Drugs/Qty/Price from inventory
def receive_inventory_reply():

    reply_queue_name = "customer.reply"
    channel.queue_declare(queue=reply_queue_name, durable=True) # make sure the queue used for "reply_to" is durable for reply messages
    channel.queue_bind(exchange=exchangename, queue=reply_queue_name, routing_key="customer.reply") # make sure the reply_to queue is bound to the exchange
    # set up a consumer and start to wait for coming messages
    channel.basic_qos(prefetch_count=1) # The "Quality of Service" setting makes the broker distribute only one message to a consumer if the consumer is available (i.e., having finished processing and acknowledged all previous messages that it receives)
    channel.basic_consume(queue=reply_queue_name,
            on_message_callback=reply_callback, # set up the function called by the broker to process a received message
    ) # prepare the reply_to receiver
    channel.start_consuming()
    

# return received inventory details as JSON to UI
def reply_callback(channel, method, properties, body):
    channel.basic_ack(delivery_tag=method.delivery_tag) # acknowledge to the broker that the processing of the message is completed
    channel.stop_consuming()
    global approved_drugs_list
    approved_drugs_list = json.loads(body)


# USER SCENARIO 2 (STEPS 3-4)
@app.route("/customer2/<string:email>")
@cross_origin(supports_credentials=True)
def get_user_health_records(email):
    user = User.query.filter_by(email = email)
    for u in user:
        return jsonify({"health_record" : u.health_records})
            
    # if no health record found 
    health_record_error(email)
    return jsonify({'message': 'Health record not found for email: ' + str(email)})

def health_record_error(email):
    message = "Error 2a: No health record found for email: " + email
    channel.queue_declare(queue='error_handler', durable=True) # make sure the queue used by the error handler exist and durable
    channel.queue_bind(exchange=exchangename, queue='error_handler', routing_key='throw.error') # make sure the queue is bound to the exchange
    channel.basic_publish(exchange=exchangename, routing_key='throw.error', body=message,
        properties=pika.BasicProperties(delivery_mode = 2) # make message persistent within the matching queues until it is received by some receiver (the matching queues have to exist and be durable and bound to the exchange)
    )
    print("No health record found, sent to error handler.")

if __name__ == '__main__':
    app.run(port=5002, debug=True)
