from flask import Flask, request
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from os import environ


import json
import sys
import os
import pika

# This version of inventory.py uses a mysql DB via flask-sqlalchemy, instead of JSON files, as the data store.

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root@localhost:3306/inventory'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
CORS(app)

class Inventory(db.Model):
    __tablename__ = 'inventory'

    drugID = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128), nullable=False)
    drug_description = db.Column(db.String(128), nullable=False)
    drug_type = db.Column(db.String(128), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Float(asdecimal=False), nullable=False)

    def json(self):
        return {
            'drugID': self.drugID,
            'name': self.name,
            'drug_description': self.drug_description,
            'drug_type': self.drug_type,
            'quantity': self.quantity,
            'price': self.price
        }

hostname = "localhost" # default hostname
port = 5672 # default port
# connect to the broker and set up a communication channel in the connection
connection = pika.BlockingConnection(pika.ConnectionParameters(host=hostname, port=port,heartbeat=600, blocked_connection_timeout=600))
    # Note: various network firewalls, filters, gateways (e.g., SMU VPN on wifi), may hinder the connections;
    # If "pika.exceptions.AMQPConnectionError" happens, may try again after disconnecting the wifi and/or disabling firewalls
channel = connection.channel()
# set up the exchange if the exchange doesn't exist

# Set up the exchange between BOOKING & INVENTORY
# exchangename2="booking_direct"
# channel.exchange_declare(exchange=exchangename2, exchange_type='direct')


# Set up the exchange between CUSTOMER & INVENTORY
exchangename="customer_direct"
channel.exchange_declare(exchange=exchangename, exchange_type='direct')

# **************************************************************************


# # Set up the exchange between BOOKING & INVENTORY
# exchangename2="booking_direct"
# channel.exchange_declare(exchange=exchangename2, exchange_type='direct')


# This chunk of codes are for exchanges between Customer Microservice and Inventory Microservice--------------------------------------------------------------------
def receiveOrder():
    # prepare a queue for receiving messages FROM CUSTOMER
    channelqueue = channel.queue_declare(queue="customer", durable=True) # 'durable' makes the queue survive broker restarts so that the messages in it survive broker restarts too
    queue_name = channelqueue.method.queue
    channel.queue_bind(exchange=exchangename, queue=queue_name, routing_key='customer.request') # bind the queue to the exchange via the key
    # set up a consumer and start to wait for coming messages
    channel.basic_qos(prefetch_count=1) # The "Quality of Service" setting makes the broker distribute only one message to a consumer if the consumer is available (i.e., having finished processing and acknowledged all previous messages that it receives)
    channel.basic_consume(queue=queue_name, on_message_callback=callback)


    # prepare a queue for receiving messages FROM BOOKING
    # channelqueue = channel.queue_declare(queue="customer", durable=True) # 'durable' makes the queue survive broker restarts so that the messages in it survive broker restarts too
    # queue_name = channelqueue.method.queue
    # channel.queue_bind(exchange=exchangename, queue=queue_name, routing_key='inventory.update') # bind the queue to the exchange via the key

    # # set up a consumer and start to wait for coming messages
    # channel.basic_qos(prefetch_count=1) # The "Quality of Service" setting makes the broker distribute only one message to a consumer if the consumer is available (i.e., having finished processing and acknowledged all previous messages that it receives)
    # channel.basic_consume(queue=queue_name, on_message_callback=processUpdate)


    print("Waiting for messages to consume...")
    channel.start_consuming() # an implicit loop waiting to receive messages; it doesn't exit by default. Use Ctrl+C in the command window to terminate it.
    
def callback(channel, method, properties, body): # required signature for the callback; no return
    print("Received an order by " + __file__)
    # print("@@@@@@@@")
    # print(body)
    # print(body.decode())
    # print(type(body.decode()))
    # body sent in Byte Class python, use .decode() to get string only
    result = processOrder(body.decode())
    # print(result)
    # print("@@@@@@@@")
    # print processing result; not really needed
    json.dump(result, sys.stdout, default=str) # convert the JSON object to a string and print out on screen
    print() # print a new line feed to the previous json dump
    print() # print another new line as a separator
    
    # prepare the reply message and send it out
    replymessage = json.dumps(result, default=str) # convert the JSON object to a string
    # print("--------")
    # print(replymessage)
    # print("--------")
    reply_queue_name = "customer_reply"
    
    channel.queue_declare(queue=reply_queue_name, durable=True) # make sure the queue used for "reply_to" is durable for reply messages
    channel.queue_bind(exchange=exchangename, queue=reply_queue_name, routing_key="customer.reply") # make sure the reply_to queue is bound to the exchange
    channel.basic_publish(exchange=exchangename,
            routing_key="customer.reply", # use the reply queue set in the request message as the routing key for reply messages
            body=replymessage, 
            properties=pika.BasicProperties(delivery_mode = 2)
    )
    channel.basic_ack(delivery_tag=method.delivery_tag) # acknowledge to the broker that the processing of the request message is completed

def processOrder(order):
    print("Processing an order:")
    print(order)
    # Can do anything here. E.g., publish a message to the error handler when processing fails.
    # resultstatus = bool(random.getrandbits( )) # simulate success/failure with a random True or False
    result = inventory_filter(order)
    print(result)
    # print(type(result))
    if result['inventory'] == "None":
        send_error()
        
    # resultmessage = json.dumps(result, default=str) # convert the JSON object to a string
    # if not resultstatus: # inform the error handler when shipping fails
    #     print("Failed shipping.")
    #     send_error(resultmessage)
    # else:
    #     print("OK shipping.")
    return result


@app.route("/<drug_type>")
def inventory_filter(drug_type):
    # split multiple approved drugs into a list

    # print(drug_type)
    # print(type(drug_type))
    # print("--------------------")
    
    drug_list2 = drug_type
    drug_list = drug_list2.split(',')
    print(drug_list)
    for i in range(len(drug_list)):
        drug_list[i] = drug_list[i].strip()
        
        
    # print("----")
    # print(drug_list)
    # print("----")

    full_inventory = []

    # Commit to db to get the latest inventory amounts
    db.session.commit()

    # retrieve all approved drugs using a loop
    for drug in drug_list:
        inventory_list = Inventory.query.filter_by(drug_type = drug).all()
        full_inventory.extend(inventory_list)

    return {'inventory': [inventory.json() for inventory in full_inventory]}

# error handler for step 3 if 
def send_error():
    # send the message to the erorr handler
    exchangename="error_handler"
    channel.exchange_declare(exchange=exchangename, exchange_type='direct')
    message = "Error 1b: User specific approved drugs field empty"
    channel.queue_declare(queue='error_handler', durable=True) # make sure the queue used by the error handler exist and durable
    channel.queue_bind(exchange=exchangename, queue='error_handler', routing_key='throw.error') # make sure the queue is bound to the exchange
    channel.basic_publish(exchange=exchangename, routing_key="throw.error", body=message,
        properties=pika.BasicProperties(delivery_mode = 2) # make message persistent within the matching queues until it is received by some receiver (the matching queues have to exist and be durable and bound to the exchange)
    )
    print("User specific approved drugs empty, sent to error handler.")


# **********************************************************************************************
# Set up the exchange between BOOKING & INVENTORY
# exchangename="customer_direct"
# channel.exchange_declare(exchange=exchangename, exchange_type='direct')



# This chunk of codes are for exchanges between Booking Microservice and Inventory Microservice-------------------------------------------------------------------------
def receiveUpdate():
    # prepare a queue for receiving messages
    channelqueue = channel.queue_declare(queue="inventory", durable=True) # 'durable' makes the queue survive broker restarts so that the messages in it survive broker restarts too
    queue_name = channelqueue.method.queue
    channel.queue_bind(exchange=exchangename, queue=queue_name, routing_key='inventory.update') # bind the queue to the exchange via the key

    # set up a consumer and start to wait for coming messages
    channel.basic_qos(prefetch_count=1) # The "Quality of Service" setting makes the broker distribute only one message to a consumer if the consumer is available (i.e., having finished processing and acknowledged all previous messages that it receives)
    channel.basic_consume(queue=queue_name, on_message_callback=processUpdate)
    print("Waiting for messages to consume FROM BOOKING...")
    channel.start_consuming() # an implicit loop waiting to receive messages; it doesn't exit by default. Use Ctrl+C in the command window to terminate it.

def processUpdate(channel, method, properties, body):
    print("Received an order by " + __file__)
    # result = processOrder(json.loads(body))
    
    # status in 2xx indicates success
    status = 201
    result = {}

    # Change JSON string into JSON object
    booking = json.loads(body)
    # Convert booking to proper dictionary format for further processing
    booking_list = ''
    for value in booking.value():
        booking_list = value

    for drug in booking_list:
        drugID = drug['drugID']
        quantity = drug['quantity']

        try:
            # Find the drug that I want to update
            current_drug = Inventory.query.filter_by(drugID=drugID)

            # Find the new quantity of the drug
            currenty_quantity = current_drug['quantity']
            new_quantity = currenty_quantity - quantity

            # Update the new quantity in the DB
            db.session.query(drugID=drugID).update({'quantity': new_quantity})
            db.session.commit()
        except Exception as e:
            status = 500
            result = {"status": status, "message": "An error occurred when creating the order in DB.", "error": str(e)}

    return str(result), status
# This chunk of codes are for exchanges between Booking Microservice and Inventory Microservice-------------------------------------------------------------------------


if __name__ == '__main__':
    receiveOrder()
