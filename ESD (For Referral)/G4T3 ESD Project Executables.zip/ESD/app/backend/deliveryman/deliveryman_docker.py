from flask import Flask, request, jsonify, make_response
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS, cross_origin
from os import environ

import json
import pika
import time


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = environ.get('dbURL')
# app.config['SQLALCHEMY_DATABASE_URI'] = environ.get('dbURL')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False


db = SQLAlchemy(app)
CORS(app, support_credentials=True)

hostname = "172.17.0.3"
port = 5672
connection = pika.BlockingConnection(pika.ConnectionParameters(host=hostname, port=port,heartbeat=600, blocked_connection_timeout=600))
channel = connection.channel()
exchangename="deliveryman_direct"
channel.exchange_declare(exchange=exchangename, exchange_type='direct')


class Deliveryman(db.Model):
    __tablename__ = 'deliveryman'
    # Data Type: Accepts one of the following: String(size), Text, DateTime, Float, Boolean, PickleType, or LargeBinary, Integer.
    customerName = db.Column(db.String(25), nullable=False)
    orderid = db.Column(db.Integer, primary_key=True)
    status = db.Column(db.String(15), nullable=False)
    email = db.Column(db.String(50), nullable=True)
    address = db.Column(db.String(50), nullable=False)
    timeslot = db.Column(db.String(50), nullable=False)

    def __init__(self, orderid, status, email, customerName, address, timeslot):
        self.customerName = customerName
        self.orderid = orderid
        self.status = status
        self.email = email
        self.address = address
        self.timeslot = timeslot

    
    def json(self):
        #convert to json format 
        return {"customerName": self.customerName, "orderid": self.orderid, "status": self.status, "email": self.email, "address": self.address, "timeslot": self.timeslot}


@app.route("/")
@cross_origin(supports_credentials=True)
def home():
    return "works"

@app.route("/all",methods = ['GET'])
@cross_origin(supports_credentials=True)
def get_schedule():
    # return all deliveryman
    return jsonify({"all": [each.json() for each in Deliveryman.query.all()]})
    


@app.route("/deliveryman/<string:orderID>", methods = ["POST"])
@cross_origin(supports_credentials=True)
def update_schedule(orderID):
    """ 
    update the status of a time slot
    json body input is in this format
    {
        "orderid": "1",
        "userid": "james.looi",
        "status": "confirmed",
        "timeslot",
        "cost",
        "address":"1 chickenrice road"
    }
    """
    data = request.get_json()
    # new = Deliveryman.query.filter(Deliveryman.userid==data['userid']).first()
    # if not data:
    #     # if no data, return error
    #     return jsonify({"message": "An error occurred updating deliveryman."}), 500

    # Add all orders into deliveryman db
    # 	orderid	status	email	customerName	address
    # order = Deliveryman(data['orders'][0]["orderid"], "Available", "", data['orders'][0]["userid"], data['orders'][0]["address"], data[0]['timeslot'])
    # db.session.add(order)
    sql = 'UPDATE deliveryman SET `status`=\"Delivery\", `email`=\"' + data['email'] + '\" WHERE `orderid`=' + orderID
    print(sql)
    try:
        db.session.execute(sql)
        db.session.commit()
    except Exception as e:
        print(e)
        return jsonify({"message": "update failed."}), 508
    #  else, update status
    # db.session.commit()
    return jsonify({"message": "update success."}), 200
    

@app.route("/deliveryman", methods = ["GET"])
@cross_origin(supports_credentials=True)
def get_status():
    """ 
    retrieve the status of a time slot
    enter ?userid=<userid> at the end of get_status. <ip>/deliveryman?userid=james.looi
    """
    userid = request.args.get('userid')
    existing = Deliveryman.query.filter(Deliveryman.userid == userid).first()
    if existing is not None:
        return existing.json()
    return "check your input values"

user_address_returned = ""
# Function to request for customer address, MATT INPUT IN JUST THE USER ID WHEN U INVOKE THIS
@app.route("/deliveryman3/<string:userID>")
@cross_origin(supports_credentials=True)
def get_user_address(userID):
    global user_address_returned 
    user_address_returned = ""
    message = userID
    # print(message)
    channel.queue_declare(queue='deliveryman_customer2', durable=True) # make sure the queue used by inventory exist and durable
    channel.queue_bind(exchange=exchangename, queue='deliveryman_customer2', routing_key='deliveryman.request2') # make sure the queue is bound to the exchange
    channel.basic_publish(exchange=exchangename, routing_key="deliveryman.request2", body=message,
        properties=pika.BasicProperties(delivery_mode = 2, # make message persistent within the matching queues until it is received by some receiver (the matching queues have to exist and be durable and bound to the exchange, which are ensured by the previous two api calls)
        )
    )
    print("User ID " + message + " sent to customer.")
    
    # Activate functions to listen and process for return
    receive_customer_reply()
    # print("@@@@@@@@@@@@")
    # print(user_address_returned)
    return jsonify({"address": user_address_returned.decode()})
    
def receive_customer_reply():
    reply_queue_name = "customer_deliveryman4"
    channel.queue_declare(queue=reply_queue_name, durable=True) # make sure the queue used for "reply_to" is durable for reply messages
    channel.queue_bind(exchange=exchangename, queue=reply_queue_name, routing_key="deliveryman.reply4") # make sure the reply_to queue is bound to the exchange
    # set up a consumer and start to wait for coming messages
    # time.sleep(1)
    channel.basic_qos(prefetch_count=1) # The "Quality of Service" setting makes the broker distribute only one message to a consumer if the consumer is available (i.e., having finished processing and acknowledged all previous messages that it receives)
    channel.basic_consume(queue=reply_queue_name,
            on_message_callback=reply_callback, # set up the function called by the broker to process a received message
    ) # prepare the reply_to receiver
    channel.start_consuming()
    
def reply_callback(channel, method, properties, body):
    global user_address_returned
    user_address_returned = body
    
    channel.stop_consuming()


# THIS FUNCTION WILL BE CALLED WHEN DELIVERYMAN HAS DELIVERED THE ITEM TO THE CUSTOMER
@app.route("/deliveryman/completed/<string:orderID>", methods = ["POST"])
def order_completed(orderID):
    # data = {'email': 'chickenricepowerup@gmail.com'}
    # data = request.get_json()

    # new = Deliveryman.query.filter(Deliveryman.userid==data['userid']).first()
    # if not data:
        # if no data, return error
        # return jsonify({"message": "An error occurred updating deliveryman."}), 500

    # Add all orders into deliveryman db
    # 	orderid	status	email	customerName	address
    # order = Deliveryman(data['orders'][0]["orderid"], "Available", "", data['orders'][0]["userid"], data['orders'][0]["address"], data[0]['timeslot'])
    # db.session.add(order)
    # sql = 'UPDATE deliveryman SET `status`=\"Delivery\", `email`=\"' + data['email'] + '\" WHERE `orderid`=' + orderID

    # SQL statement to delete data from SQL table based on orderID
    sql = 'DELETE FROM deliveryman WHERE `orderid`=' + orderID
    # print(sql)
    try:
        db.session.execute(sql)
        db.session.commit()

        # Send orderID to "booking_deliveryman_completion.py" to delete the entry in Booking DB as well
        exchangename="booking_completed_updatedb"
        queue_name = "booking_completed"
        
        message = {'orderID': orderID}
        message = json.dumps(message)

        channel.exchange_declare(exchange=exchangename, exchange_type='direct')
        channel.queue_declare(queue=queue_name, durable=True) # make sure the queue used by the error handler exist and durable
        channel.queue_bind(exchange=exchangename, queue=queue_name, routing_key="booking.completed") # make sure the queue is bound to the exchange
        channel.basic_publish(exchange=exchangename, routing_key="booking.completed", body=message,
            properties=pika.BasicProperties(delivery_mode = 2) # make message persistent within the matching queues until it is received by some receiver (the matching queues have to exist and be durable and bound to the exchange)
        )
        print("orderID has been sent to booking_deliveryman_completion.py to be processed.")

    except Exception as e:
        print(e)
        return jsonify({"message": "delete failed."}), 508
    #  else, update status
    # db.session.commit()
    return jsonify({"message": "delete success."}), 200
# --------------------------------------------------------------------------------------


if __name__ == "__main__":
    app.run(host='0.0.0.0', port='5006',debug=True)
    # update_schedule()