from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS, cross_origin
# from booking import find_order_details
from os import environ


import json
import sys
import os
import random

# Communication patterns:
# Use a message-broker with 'direct' exchange to enable interaction
import pika


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = environ.get('dbURL')
# create the DB and change the url
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
 
db = SQLAlchemy(app)
app.config['CORS_HEADERS'] = 'Content-Type'

class Booking(db.Model):
    __tablename__ = 'booking'

    orderid = db.Column(db.Integer, primary_key=True)
    userid = db.Column(db.String(50), nullable = False)
    drugsOrdered = db.Column(db.String(100), primary_key=True)
    drugQuantity = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(100), nullable=False)
    timeslot = db.Column(db.DateTime, nullable=False)
    cost = db.Column(db.Float(), nullable = False)
    address = db.Column(db.String(50), nullable = False)

    def __init__(self, orderid, userid, drugsOrdered, drugQuantity, status, timeslot, cost, address):
        self.orderid = orderid
        self.userid = userid
        self.drugsOrdered = drugsOrdered
        self.drugQuantity = drugQuantity
        self.status = status
        self.timeslot = timeslot
        self.cost = cost
        self.address = address

    def json(self):
        return {
            'orderid': self.orderid,
            'userid': self.userid, 
            'drugsOrdered': self.drugsOrdered,
            'drugQuantity': self.drugQuantity,
            'status': self.status,
            'timeslot': self.timeslot,
            'cost': self.cost,
            'address': self.address
        }
    
    def getTimeslot(self):
        return self.timeslot

hostname = "172.17.0.3" # default hostname
port = 5672 # default port
# connect to the broker and set up a communication channel in the connection
connection = pika.BlockingConnection(pika.ConnectionParameters(host=hostname, port=port))
    # Note: various network firewalls, filters, gateways (e.g., SMU VPN on wifi), may hinder the connections;
    # If "pika.exceptions.AMQPConnectionError" happens, may try again after disconnecting the wifi and/or disabling firewalls
channel = connection.channel()
# set up the exchange if the exchange doesn't exist
exchangename="pharmacist_booking_update"
channel.exchange_declare(exchange=exchangename, exchange_type='direct')

def find_order_details(request_id):

    orders = Booking.query.filter_by(orderid=request_id).all()
    if orders:
        timeslot = orders[0].timeslot
        ordersDict = {}
        for order in orders:
            # <Booking 104, Gaviscon>
            # <Booking 104, Paracetamol>
            ordersDict[order.drugsOrdered] = order.drugQuantity

        finalDict = {}
        finalDict['timeslot'] = timeslot
        finalDict['orders'] = ordersDict

        return finalDict
    return ({"Message": "Order not found."}),404

def receiveBooking():  
    print("RECEIVED BOOKING LOOK HERE NOW", flush=True)
    channelqueue = channel.queue_declare(queue="booking", durable=True) # 'durable' makes the queue survive broker restarts so that the messages in it survive broker restarts too
    queue_name = channelqueue.method.queue
    channel.queue_bind(exchange=exchangename, queue=queue_name, routing_key='pharmacist.update') # bind the queue to the exchange via the key

    # set up a consumer and start to wait for coming messages
    channel.basic_qos(prefetch_count=1) # The "Quality of Service" setting makes the broker distribute only one message to a consumer if the consumer is available (i.e., having finished processing and acknowledged all previous messages that it receives)
    print("RECEIVED BOOKING LOOK HERE NOW 2222222", flush=True)

    channel.basic_consume(queue=queue_name, on_message_callback=callback)

    print("WAITING FOR MESSAGES...", flush=True)
    channel.start_consuming()
    # print("----Starting----")

def callback(channel, method, properties, body): # required signature for the callback; no return
    # result = updateBooking(json.loads(body))
    print("@@@@@@", flush=True)
    print(body)
    print("@@@@@@", flush=True)
    result = updateBooking(json.loads(body))
    # result = "123"

    channel.basic_ack(delivery_tag=method.delivery_tag)
    # channel.stop_consuming()

# @app.route('/booking/pharmacist/<string:inp>', methods=['GET'])
def updateBooking(inp):
    # inpid = json.dumps(inp["id"], default = str)
    print("-----------------", flush=True)
    print(inp, flush=True)
    inpid = inp["id"]
    print(inpid, flush=True)
    sql = "UPDATE booking SET status = 'confirmed' WHERE orderid =" + inpid
    print(sql, flush=True)
    print("-----------------", flush=True)
    db.session.execute(sql)
    try:
        db.session.commit()
    except Exception as e: 
        # return('Failed')
        return {"message": "Failed"},500
    
    # return {"message": "Success"},201
    try:

        updateSchedule(inpid)

    except Exception as e:
        return {"message": "Failed"},501
    
    try:
        updateInventory(inpid)

    except Exception as e:
        return {"message": "Failed"},502
    
    # return("Success, timeslot send to schedule")

def updateSchedule(inpid):
    connection = pika.BlockingConnection(pika.ConnectionParameters(host=hostname, port=port))
    channel = connection.channel()

    # set up the exchange if the exchange doesn't exist
    exchangename="booking_schedule_update"
    channel.exchange_declare(exchange=exchangename, exchange_type='direct')

    # inpid = inpid.strip("\"")
    allOrders = find_order_details(inpid)

    message = json.dumps(allOrders, default=str)

    # channel.basic_publish(exchange=exchangename, routing_key="schedule.update", body=message)

    replyqueuename = "booking_schedule_reply"
        # inform Booking and exit
        # prepare the channel and send a message to Booking
    channel.queue_declare(queue='schedule', durable=True) 
    channel.queue_bind(exchange=exchangename, queue='schedule', routing_key='schedule.update')
    channel.basic_publish(exchange=exchangename, routing_key="schedule.update", body=message,
     properties=pika.BasicProperties(delivery_mode = 1, 
            ))
    
    print("Approval sent to schedule.", flush=True)
    # close the connection to the broker

    connection.close()

# @app.route('/booking/update/<string:inpid>')
def updateInventory(inpid):
    connection = pika.BlockingConnection(pika.ConnectionParameters(host=hostname, port=port))
    channel = connection.channel()

    # set up the exchange if the exchange doesn't exist
    exchangename="booking_inventory_update"
    channel.exchange_declare(exchange=exchangename, exchange_type='direct')

    order = find_order_details(inpid)

    message = json.dumps(order['orders'], default=str)

    # channel.basic_publish(exchange=exchangename, routing_key="schedule.update", body=message)

    replyqueuename = "booking_inventory_reply"
        # inform Booking and exit
        # prepare the channel and send a message to Booking
    channel.queue_declare(queue='inventory', durable=True) 
    channel.queue_bind(exchange=exchangename, queue='inventory', routing_key='inventory.update') 
    channel.basic_publish(exchange=exchangename, routing_key="inventory.update", body=message,
     properties=pika.BasicProperties(delivery_mode = 1,
            ))
    
    print("Approval sent to inventory.", flush=True)
    # close the connection to the broker

    connection.close()

    return ""

if __name__ == "__main__":  # execute this program only if it is run as a script (not by 'import')
    # app.run(host="0.0.0.0", port=5002, debug=True)
    print("lol", flush=True)
    receiveBooking()