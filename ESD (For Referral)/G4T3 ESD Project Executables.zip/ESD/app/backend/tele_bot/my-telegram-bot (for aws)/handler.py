import json
import os
import sys
import logging


here = os.path.dirname(os.path.realpath(__file__))
sys.path.append(os.path.join(here, "./vendored"))

import requests
from requests.exceptions import HTTPError

TOKEN = os.environ['TELEGRAM_TOKEN']
BASE_URL = "https://api.telegram.org/bot{}".format(TOKEN)
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)


def hello(event, context):
    try:
        data = json.loads(event["body"])
        message = str(data["message"]["text"])
        chat_id = data["message"]["chat"]["id"]
        first_name = data["message"]["chat"]["first_name"]

        try:
            # url_call = "http://192.168.29.161:5008/booking/" + message
            # url_call = "http://202.161.35.27:5008/booking/" + message
            url_call = "http://34.203.171.121:8000/"
            contents = requests.get(url_call,timeout=2)
            contents = requests.get(url).json()    
            status = contents['orders'][0]['status']
            cost = contents['orders'][0]['cost']
            response = f"The status of your order is: {status}.\nPrice is: {cost}\nThank you!"
            # response = f"The status of your order is: {contents.status_code}"
        except HTTPError as http_err:
            response = (f'HTTP error occurred: {http_err}')

        # else:
        #     respones = "failure"
        # except:
        #     response = "Sorry, I didn't understand that command.\nPlease enter a valid order ID"


        # response = "Please /start, {}".format(first_name)

        # if "start" in message:
        #     response = "Hello {}".format(first_name)

        data = {"text": response.encode("utf8"), "chat_id": chat_id}
        url = BASE_URL + "/sendMessage"
        requests.post(url, data)

    except Exception as e:
        print(e)

    return {"statusCode": 200}