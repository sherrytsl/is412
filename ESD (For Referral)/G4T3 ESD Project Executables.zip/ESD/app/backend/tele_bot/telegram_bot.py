from telegram.ext import Updater, InlineQueryHandler, CommandHandler, MessageHandler, Filters
import requests
import random
import logging

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger()


# def get_url():
#     # contents = requests.get('https://random.dog/woof.json').json() 
#     contents = requests.get('http://172.17.110.209:5008/booking/102').json()    
#     # return contents
#     orders = contents['status']
#     # for each in orders:
#     #     print (each)
#     return orders

# def bop(bot, update):
#     url = "http://172.17.110.209:5008/booking/102"
#     #  + message_text
#     contents = requests.get(url).json()    
#     status = contents['orders'][0]['status']
#     update.message.reply_text("status: {}".format(status))




# def random_handler(bot, update):
#     # Creating a handler-function for /random command
#     number = random.randint(0, 10)
#     logger.info("User {} randomed number {}".format(update.effective_user["id"], number))
#     update.message.reply_text("Random number: {}".format(number))



def start_handler(bot, update):
    # Creating a handler-function for /start command 
    logger.info("User {} started bot".format(update.effective_user["id"]))
    update.message.reply_text("Hello from G4T3!\nPlease enter your order ID.")


def return_order_status(bot, update):
    text = update.message.text
    logger.info("User {} entered {}".format(update.effective_user["id"], text))
    try:
        # NOTE MUST CHANGE THIS URL TO HOST COMPUTER'S IP (CHECK VIA IPCONFIG)
        url = "http://172.18.53.193:5008/booking/" + text
        contents = requests.get(url).json()    
        status = contents['orders'][0]['status']
        cost = contents['orders'][0]['cost']
        update.message.reply_text(f"The status of your order is: {status}.\nPrice is: {cost}\nThank you!")
    except:
        update.message.reply_text(f"Please enter a valid order ID")
    

def unknown(bot, update):
    logger.info("User {} entered {}".format(update.effective_user["id"], update.message.text))
    update.message.reply_text("Sorry, I didn't understand that command.")



def main():
    updater = Updater('1186152916:AAHZuhDSAFEz3v16VsvERKQ3U9wOvSwf_KA')
    dp = updater.dispatcher
    # dp.add_handler(CommandHandler('bop',bop))
    # dp.add_handler(CommandHandler("random", random_handler))

    dp.add_handler(CommandHandler("start", start_handler))
    dp.add_handler(MessageHandler(Filters.command, unknown))
    dp.add_handler(MessageHandler(Filters.text, return_order_status))

    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()